﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SahlaTranportLogistics
{
    public partial class Driver : Form
    {
        public Driver()
        {
            InitializeComponent();
        }

        private void DisplayData()
        {
            SqlConnection con = new SqlConnection(@"Data Source=HP\ISMAIL;Initial Catalog=SahalTLDB;Integrated Security=True");
            SqlDataAdapter adapt;
            con.Open();
            DataTable dt = new DataTable();
            adapt = new SqlDataAdapter("select * from Passanger", con);
            adapt.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }

        private void Label3_Click(object sender, EventArgs e)
        {

        }

        private void Label4_Click(object sender, EventArgs e)
        {

        }

        private void TxtSerialno_TextChanged(object sender, EventArgs e)
        {

        }

        private void Guna2Button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=HP\ISMAIL;Initial Catalog=SahalTLDB;Integrated Security=True");
            con.Open();
            try
            {
                string str = " INSERT INTO Driver(DriverID,Drivername,DriverLicien,Driversalary,DriverBusno,Age) VALUES('" + txtDriverID1.Text + "','" + txtDrivername.Text + "' ,'" + txtDriverLicien.Text + "' ,'" + txtDriversalary.Text + "' ,'" + txtDBno.Text + "','" + txtAge.Text + "'); ";
                SqlCommand cmd = new SqlCommand(str, con);
                cmd.ExecuteNonQuery();
                string str1 = "select max(DriverID) from Driver ;";
                SqlCommand cmd1 = new SqlCommand(str1, con);
                SqlDataReader dr = cmd1.ExecuteReader();
                DisplayData();
                if (dr.Read())
                {
                    MessageBox.Show("Successfully Saved. ");
                }
            }
            catch (SqlException excep)
            {
                MessageBox.Show(excep.Message);
            }
            con.Close();

            DisplayData();

        }

        private void Guna2Button6_Click(object sender, EventArgs e)
        {
            txtDriverID1.Text = "";
            txtDrivername.Text = "";
            txtDriverLicien.Text = "";
            txtDriversalary.Text = "";
            txtAge.Text = "";
            txtDBno.Text = ""; 
        }

        private void Guna2Button3_Click(object sender, EventArgs e)
        {
            MainPage fr = new MainPage();
            fr.Show();
            this.Hide();
        }

        private void Driver_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'sahalTLDBDataSet2.Driver' table. You can move, or remove it, as needed.
            this.driverTableAdapter.Fill(this.sahalTLDBDataSet2.Driver);

        }

        private void Guna2Button2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=HP\ISMAIL;Initial Catalog=SahalTLDB;Integrated Security=True");
            SqlCommand cmd;
            if (txtDriverID1.Text != "" && txtDrivername.Text != "" && txtDriverLicien.Text != "" && txtDriversalary.Text != "" && txtDBno.Text != "" && txtAge.Text != "")
            {
                cmd = new SqlCommand("update Driver set DriverID=@DriverID, Drivername=@Drivername,  DriverLicien=@DriverLicien, Driversalary=@Driversalary, DriverBusno=@DriverBusno, Age=@Age where DriverID=@DriverID", con);
                con.Open();

                cmd.Parameters.AddWithValue("@DriverID", txtDriverID1.Text);
                cmd.Parameters.AddWithValue("@Drivername", txtDrivername.Text);
                cmd.Parameters.AddWithValue("@DriverLicien", txtDriverLicien.Text);
                cmd.Parameters.AddWithValue("@Driversalary", txtDriversalary.Text);
                cmd.Parameters.AddWithValue("@DriverBusno", txtDBno.Text);
                cmd.Parameters.AddWithValue("@Age", txtAge.Text);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Record Updated ");
                con.Close();
            }
            else
            {
                MessageBox.Show("Please Select Record to Update");
            }
            DisplayData();
        }

        private void TxtDriverLicien_TextChanged(object sender, EventArgs e)
        {

        }

        private void Guna2Button5_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=HP\ISMAIL;Initial Catalog=SahalTLDB;Integrated Security=True");
                {
                    string str1 = @"SELECT * from Driver where DriverID = '" + txtPsid.Text + "'";
                    SqlCommand cmd1 = new SqlCommand(str1, con);
                    SqlDataAdapter da = new SqlDataAdapter(cmd1);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dataGridView1.DataSource = new BindingSource(dt, null);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                MessageBox.Show("Please Enter Passanger ID");
            }
        }

        private void Guna2Button4_Click(object sender, EventArgs e)
        {

            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=HP\ISMAIL;Initial Catalog=SahalTLDB;Integrated Security=True");
                con.Open();

                string str = "DELETE FROM Driver WHERE DriverID = '" + txtPsid.Text + "'";

                SqlCommand cmd = new SqlCommand(str, con);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Record Delete Successfully");

                using (SqlConnection newcon = new SqlConnection(@"Data Source=HP\ISMAIL;Initial Catalog=SahalTLDB;Integrated Security=True"))
                {
                    string str1 = @"SELECT * from Driver";
                    SqlCommand cmd1 = new SqlCommand(str1, newcon);
                    SqlDataAdapter da = new SqlDataAdapter(cmd1);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dataGridView1.DataSource = new BindingSource(dt, null);

                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                MessageBox.Show("Please Enter Passanger Id");
            }
            DisplayData();
        }

        private void TxtPsid_TextChanged(object sender, EventArgs e)
        {

        }

        private void Guna2Button7_Click(object sender, EventArgs e)
        {
            DrReForm fr = new DrReForm();
            fr.Show();

        }
    }
}
