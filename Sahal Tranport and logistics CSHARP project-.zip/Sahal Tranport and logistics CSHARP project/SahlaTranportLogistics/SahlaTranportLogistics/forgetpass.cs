﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SahlaTranportLogistics
{
    public partial class forgetpass : Form
    {
        public forgetpass()
        {
            InitializeComponent();
        }

        private void PictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void Forgetpass_Load(object sender, EventArgs e)
        {

        }

        private void Guna2Button2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=HP\ISMAIL;Initial Catalog=SahalTLDB;Integrated Security=True");
            SqlCommand cmd;
            if (txtUsername.Text != "" && txtPassword.Text != "" )
            {
                cmd = new SqlCommand("UPDATE Register set Username=@Username, Pass=@Pass   where Username=@Username", con);
                con.Open();

                cmd.Parameters.AddWithValue("@Username", txtUsername.Text);
                cmd.Parameters.AddWithValue("@Pass", txtPassword.Text);
               
                cmd.ExecuteNonQuery();
                MessageBox.Show("Record Updated");
                con.Close();
            }
            else
            {
                MessageBox.Show("Please Select Record to Update");
            }
        }

        private void Guna2Button1_Click(object sender, EventArgs e)
        {
            Login mr = new Login();
            mr.Show();
            this.Close();
        }

        private void TxtUsername_TextChanged(object sender, EventArgs e)
        {

        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void Label2_Click(object sender, EventArgs e)
        {

        }

        private void Label3_Click(object sender, EventArgs e)
        {

        }
    }
}
