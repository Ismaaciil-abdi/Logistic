﻿namespace SahlaTranportLogistics
{
    partial class MngRFrom
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource2 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.ManagerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.SahalTLDBDataSet3 = new SahlaTranportLogistics.SahalTLDBDataSet3();
            this.CargoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.SahalTLDBDataSet1 = new SahlaTranportLogistics.SahalTLDBDataSet1();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.ManagerTableAdapter = new SahlaTranportLogistics.SahalTLDBDataSet3TableAdapters.ManagerTableAdapter();
            this.SahalTLDBDataSet4 = new SahlaTranportLogistics.SahalTLDBDataSet4();
            this.CargoTableAdapter = new SahlaTranportLogistics.SahalTLDBDataSet1TableAdapters.CargoTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.ManagerBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SahalTLDBDataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CargoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SahalTLDBDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SahalTLDBDataSet4)).BeginInit();
            this.SuspendLayout();
            // 
            // ManagerBindingSource
            // 
            this.ManagerBindingSource.DataMember = "Manager";
            this.ManagerBindingSource.DataSource = this.SahalTLDBDataSet3;
            // 
            // SahalTLDBDataSet3
            // 
            this.SahalTLDBDataSet3.DataSetName = "SahalTLDBDataSet3";
            this.SahalTLDBDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // CargoBindingSource
            // 
            this.CargoBindingSource.DataMember = "Cargo";
            this.CargoBindingSource.DataSource = this.SahalTLDBDataSet1;
            // 
            // SahalTLDBDataSet1
            // 
            this.SahalTLDBDataSet1.DataSetName = "SahalTLDBDataSet1";
            this.SahalTLDBDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // reportViewer1
            // 
            this.reportViewer1.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource1.Name = "DataSet1";
            reportDataSource1.Value = this.ManagerBindingSource;
            reportDataSource2.Name = "CrDataSet2";
            reportDataSource2.Value = this.CargoBindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource2);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "SahlaTranportLogistics.Report1.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(0, 0);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.ServerReport.BearerToken = null;
            this.reportViewer1.Size = new System.Drawing.Size(800, 582);
            this.reportViewer1.TabIndex = 0;
            this.reportViewer1.Load += new System.EventHandler(this.ReportViewer1_Load);
            // 
            // ManagerTableAdapter
            // 
            this.ManagerTableAdapter.ClearBeforeFill = true;
            // 
            // SahalTLDBDataSet4
            // 
            this.SahalTLDBDataSet4.DataSetName = "SahalTLDBDataSet4";
            this.SahalTLDBDataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // CargoTableAdapter
            // 
            this.CargoTableAdapter.ClearBeforeFill = true;
            // 
            // MngRFrom
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 582);
            this.Controls.Add(this.reportViewer1);
            this.Name = "MngRFrom";
            this.Text = "MngRFrom";
            this.Load += new System.EventHandler(this.MngRFrom_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ManagerBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SahalTLDBDataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CargoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SahalTLDBDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SahalTLDBDataSet4)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private System.Windows.Forms.BindingSource ManagerBindingSource;
        private SahalTLDBDataSet3 SahalTLDBDataSet3;
        private SahalTLDBDataSet3TableAdapters.ManagerTableAdapter ManagerTableAdapter;
        private SahalTLDBDataSet4 SahalTLDBDataSet4;
        private System.Windows.Forms.BindingSource CargoBindingSource;
        private SahalTLDBDataSet1 SahalTLDBDataSet1;
        private SahalTLDBDataSet1TableAdapters.CargoTableAdapter CargoTableAdapter;
    }
}