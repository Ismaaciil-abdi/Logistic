﻿namespace SahlaTranportLogistics
{
    partial class Cargo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txtPrice = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtQuantity = new Guna.UI2.WinForms.Guna2TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtForm = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtTO = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtRecievernumber = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtRecievername = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtsandernumber = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtsandername = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtSerialno = new Guna.UI2.WinForms.Guna2TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.guna2Button5 = new Guna.UI2.WinForms.Guna2Button();
            this.label11 = new System.Windows.Forms.Label();
            this.txtPsid = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2Button3 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button4 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button2 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.serialnoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sandernameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sandernumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.recievernameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.recievernumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gongToDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.formtoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.quantityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pirceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cargoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sahalTLDBDataSet1 = new SahlaTranportLogistics.SahalTLDBDataSet1();
            this.cargoTableAdapter = new SahlaTranportLogistics.SahalTLDBDataSet1TableAdapters.CargoTableAdapter();
            this.guna2Button6 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button7 = new Guna.UI2.WinForms.Guna2Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cargoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sahalTLDBDataSet1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtPrice
            // 
            this.txtPrice.BorderRadius = 12;
            this.txtPrice.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtPrice.DefaultText = "";
            this.txtPrice.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtPrice.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtPrice.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtPrice.DisabledState.Parent = this.txtPrice;
            this.txtPrice.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtPrice.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.txtPrice.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtPrice.FocusedState.Parent = this.txtPrice;
            this.txtPrice.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPrice.ForeColor = System.Drawing.Color.White;
            this.txtPrice.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtPrice.HoverState.Parent = this.txtPrice;
            this.txtPrice.Location = new System.Drawing.Point(194, 523);
            this.txtPrice.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.PasswordChar = '\0';
            this.txtPrice.PlaceholderText = "";
            this.txtPrice.SelectedText = "";
            this.txtPrice.ShadowDecoration.Parent = this.txtPrice;
            this.txtPrice.Size = new System.Drawing.Size(229, 44);
            this.txtPrice.TabIndex = 39;
            // 
            // txtQuantity
            // 
            this.txtQuantity.BorderRadius = 12;
            this.txtQuantity.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtQuantity.DefaultText = "";
            this.txtQuantity.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtQuantity.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtQuantity.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtQuantity.DisabledState.Parent = this.txtQuantity;
            this.txtQuantity.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtQuantity.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.txtQuantity.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtQuantity.FocusedState.Parent = this.txtQuantity;
            this.txtQuantity.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQuantity.ForeColor = System.Drawing.Color.White;
            this.txtQuantity.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtQuantity.HoverState.Parent = this.txtQuantity;
            this.txtQuantity.Location = new System.Drawing.Point(194, 471);
            this.txtQuantity.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtQuantity.Name = "txtQuantity";
            this.txtQuantity.PasswordChar = '\0';
            this.txtQuantity.PlaceholderText = "";
            this.txtQuantity.SelectedText = "";
            this.txtQuantity.ShadowDecoration.Parent = this.txtQuantity;
            this.txtQuantity.Size = new System.Drawing.Size(229, 44);
            this.txtQuantity.TabIndex = 38;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Poppins", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(12, 476);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(103, 34);
            this.label9.TabIndex = 37;
            this.label9.Text = "Quantity";
            this.label9.Click += new System.EventHandler(this.Label9_Click);
            // 
            // txtForm
            // 
            this.txtForm.BorderRadius = 12;
            this.txtForm.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtForm.DefaultText = "";
            this.txtForm.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtForm.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtForm.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtForm.DisabledState.Parent = this.txtForm;
            this.txtForm.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtForm.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.txtForm.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtForm.FocusedState.Parent = this.txtForm;
            this.txtForm.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtForm.ForeColor = System.Drawing.Color.White;
            this.txtForm.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtForm.HoverState.Parent = this.txtForm;
            this.txtForm.Location = new System.Drawing.Point(194, 419);
            this.txtForm.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtForm.Name = "txtForm";
            this.txtForm.PasswordChar = '\0';
            this.txtForm.PlaceholderText = "";
            this.txtForm.SelectedText = "";
            this.txtForm.ShadowDecoration.Parent = this.txtForm;
            this.txtForm.Size = new System.Drawing.Size(229, 44);
            this.txtForm.TabIndex = 36;
            // 
            // txtTO
            // 
            this.txtTO.BorderRadius = 12;
            this.txtTO.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtTO.DefaultText = "";
            this.txtTO.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtTO.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtTO.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtTO.DisabledState.Parent = this.txtTO;
            this.txtTO.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtTO.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.txtTO.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtTO.FocusedState.Parent = this.txtTO;
            this.txtTO.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTO.ForeColor = System.Drawing.Color.White;
            this.txtTO.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtTO.HoverState.Parent = this.txtTO;
            this.txtTO.Location = new System.Drawing.Point(194, 367);
            this.txtTO.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtTO.Name = "txtTO";
            this.txtTO.PasswordChar = '\0';
            this.txtTO.PlaceholderText = "";
            this.txtTO.SelectedText = "";
            this.txtTO.ShadowDecoration.Parent = this.txtTO;
            this.txtTO.Size = new System.Drawing.Size(229, 44);
            this.txtTO.TabIndex = 35;
            // 
            // txtRecievernumber
            // 
            this.txtRecievernumber.BorderRadius = 12;
            this.txtRecievernumber.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtRecievernumber.DefaultText = "";
            this.txtRecievernumber.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtRecievernumber.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtRecievernumber.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtRecievernumber.DisabledState.Parent = this.txtRecievernumber;
            this.txtRecievernumber.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtRecievernumber.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.txtRecievernumber.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtRecievernumber.FocusedState.Parent = this.txtRecievernumber;
            this.txtRecievernumber.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRecievernumber.ForeColor = System.Drawing.Color.White;
            this.txtRecievernumber.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtRecievernumber.HoverState.Parent = this.txtRecievernumber;
            this.txtRecievernumber.Location = new System.Drawing.Point(194, 315);
            this.txtRecievernumber.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtRecievernumber.Name = "txtRecievernumber";
            this.txtRecievernumber.PasswordChar = '\0';
            this.txtRecievernumber.PlaceholderText = "";
            this.txtRecievernumber.SelectedText = "";
            this.txtRecievernumber.ShadowDecoration.Parent = this.txtRecievernumber;
            this.txtRecievernumber.Size = new System.Drawing.Size(229, 44);
            this.txtRecievernumber.TabIndex = 34;
            // 
            // txtRecievername
            // 
            this.txtRecievername.BorderRadius = 12;
            this.txtRecievername.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtRecievername.DefaultText = "";
            this.txtRecievername.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtRecievername.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtRecievername.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtRecievername.DisabledState.Parent = this.txtRecievername;
            this.txtRecievername.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtRecievername.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.txtRecievername.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtRecievername.FocusedState.Parent = this.txtRecievername;
            this.txtRecievername.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRecievername.ForeColor = System.Drawing.Color.White;
            this.txtRecievername.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtRecievername.HoverState.Parent = this.txtRecievername;
            this.txtRecievername.Location = new System.Drawing.Point(194, 263);
            this.txtRecievername.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtRecievername.Name = "txtRecievername";
            this.txtRecievername.PasswordChar = '\0';
            this.txtRecievername.PlaceholderText = "";
            this.txtRecievername.SelectedText = "";
            this.txtRecievername.ShadowDecoration.Parent = this.txtRecievername;
            this.txtRecievername.Size = new System.Drawing.Size(229, 44);
            this.txtRecievername.TabIndex = 33;
            // 
            // txtsandernumber
            // 
            this.txtsandernumber.BorderRadius = 12;
            this.txtsandernumber.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtsandernumber.DefaultText = "";
            this.txtsandernumber.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtsandernumber.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtsandernumber.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtsandernumber.DisabledState.Parent = this.txtsandernumber;
            this.txtsandernumber.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtsandernumber.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.txtsandernumber.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtsandernumber.FocusedState.Parent = this.txtsandernumber;
            this.txtsandernumber.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsandernumber.ForeColor = System.Drawing.Color.White;
            this.txtsandernumber.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtsandernumber.HoverState.Parent = this.txtsandernumber;
            this.txtsandernumber.Location = new System.Drawing.Point(194, 211);
            this.txtsandernumber.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtsandernumber.Name = "txtsandernumber";
            this.txtsandernumber.PasswordChar = '\0';
            this.txtsandernumber.PlaceholderText = "";
            this.txtsandernumber.SelectedText = "";
            this.txtsandernumber.ShadowDecoration.Parent = this.txtsandernumber;
            this.txtsandernumber.Size = new System.Drawing.Size(229, 44);
            this.txtsandernumber.TabIndex = 32;
            // 
            // txtsandername
            // 
            this.txtsandername.BorderRadius = 12;
            this.txtsandername.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtsandername.DefaultText = "";
            this.txtsandername.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtsandername.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtsandername.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtsandername.DisabledState.Parent = this.txtsandername;
            this.txtsandername.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtsandername.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.txtsandername.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtsandername.FocusedState.Parent = this.txtsandername;
            this.txtsandername.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsandername.ForeColor = System.Drawing.Color.White;
            this.txtsandername.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtsandername.HoverState.Parent = this.txtsandername;
            this.txtsandername.Location = new System.Drawing.Point(194, 157);
            this.txtsandername.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtsandername.Name = "txtsandername";
            this.txtsandername.PasswordChar = '\0';
            this.txtsandername.PlaceholderText = "";
            this.txtsandername.SelectedText = "";
            this.txtsandername.ShadowDecoration.Parent = this.txtsandername;
            this.txtsandername.Size = new System.Drawing.Size(229, 44);
            this.txtsandername.TabIndex = 31;
            this.txtsandername.TextChanged += new System.EventHandler(this.Txtsandername_TextChanged);
            // 
            // txtSerialno
            // 
            this.txtSerialno.BorderRadius = 12;
            this.txtSerialno.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSerialno.DefaultText = "";
            this.txtSerialno.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtSerialno.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtSerialno.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtSerialno.DisabledState.Parent = this.txtSerialno;
            this.txtSerialno.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtSerialno.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.txtSerialno.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtSerialno.FocusedState.Parent = this.txtSerialno;
            this.txtSerialno.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSerialno.ForeColor = System.Drawing.Color.White;
            this.txtSerialno.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtSerialno.HoverState.Parent = this.txtSerialno;
            this.txtSerialno.Location = new System.Drawing.Point(194, 104);
            this.txtSerialno.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtSerialno.Name = "txtSerialno";
            this.txtSerialno.PasswordChar = '\0';
            this.txtSerialno.PlaceholderText = "";
            this.txtSerialno.SelectedText = "";
            this.txtSerialno.ShadowDecoration.Parent = this.txtSerialno;
            this.txtSerialno.Size = new System.Drawing.Size(229, 44);
            this.txtSerialno.TabIndex = 30;
            this.txtSerialno.TextChanged += new System.EventHandler(this.TxtSerialno_TextChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Poppins", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(12, 528);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(64, 34);
            this.label10.TabIndex = 29;
            this.label10.Text = "Price";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Poppins", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(12, 424);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(65, 34);
            this.label8.TabIndex = 28;
            this.label8.Text = "Form";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Poppins", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(12, 372);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(41, 34);
            this.label7.TabIndex = 27;
            this.label7.Text = "TO";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Poppins", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(12, 320);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(183, 34);
            this.label6.TabIndex = 26;
            this.label6.Text = "Reciever number";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Poppins", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(12, 268);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(162, 34);
            this.label5.TabIndex = 25;
            this.label5.Text = "Reciever name";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Poppins", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(12, 216);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(169, 34);
            this.label4.TabIndex = 24;
            this.label4.Text = "Sander number";
            this.label4.Click += new System.EventHandler(this.Label4_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Poppins", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(12, 162);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(148, 34);
            this.label3.TabIndex = 23;
            this.label3.Text = "Sander name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Poppins", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(12, 109);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(105, 34);
            this.label2.TabIndex = 22;
            this.label2.Text = "Serial NO";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1370, 64);
            this.panel1.TabIndex = 40;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Poppins", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(475, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(226, 56);
            this.label1.TabIndex = 0;
            this.label1.Text = "Cargo F orm";
            // 
            // guna2Button5
            // 
            this.guna2Button5.BorderRadius = 12;
            this.guna2Button5.CheckedState.Parent = this.guna2Button5;
            this.guna2Button5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2Button5.CustomImages.Parent = this.guna2Button5;
            this.guna2Button5.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.guna2Button5.Font = new System.Drawing.Font("Poppins Black", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button5.ForeColor = System.Drawing.Color.White;
            this.guna2Button5.HoverState.BorderColor = System.Drawing.Color.Lime;
            this.guna2Button5.HoverState.CustomBorderColor = System.Drawing.Color.Lime;
            this.guna2Button5.HoverState.FillColor = System.Drawing.Color.Tomato;
            this.guna2Button5.HoverState.Parent = this.guna2Button5;
            this.guna2Button5.Location = new System.Drawing.Point(469, 159);
            this.guna2Button5.Name = "guna2Button5";
            this.guna2Button5.ShadowDecoration.Parent = this.guna2Button5;
            this.guna2Button5.Size = new System.Drawing.Size(135, 50);
            this.guna2Button5.TabIndex = 47;
            this.guna2Button5.Text = "s e a r c h";
            this.guna2Button5.Click += new System.EventHandler(this.Guna2Button5_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Poppins", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(468, 202);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(0, 34);
            this.label11.TabIndex = 46;
            // 
            // txtPsid
            // 
            this.txtPsid.BorderRadius = 12;
            this.txtPsid.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtPsid.DefaultText = "";
            this.txtPsid.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtPsid.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtPsid.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtPsid.DisabledState.Parent = this.txtPsid;
            this.txtPsid.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtPsid.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.txtPsid.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtPsid.FocusedState.Parent = this.txtPsid;
            this.txtPsid.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPsid.ForeColor = System.Drawing.Color.White;
            this.txtPsid.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtPsid.HoverState.Parent = this.txtPsid;
            this.txtPsid.Location = new System.Drawing.Point(615, 162);
            this.txtPsid.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtPsid.Name = "txtPsid";
            this.txtPsid.PasswordChar = '\0';
            this.txtPsid.PlaceholderText = "";
            this.txtPsid.SelectedText = "";
            this.txtPsid.ShadowDecoration.Parent = this.txtPsid;
            this.txtPsid.Size = new System.Drawing.Size(518, 44);
            this.txtPsid.TabIndex = 45;
            this.txtPsid.TextChanged += new System.EventHandler(this.TxtPsid_TextChanged);
            // 
            // guna2Button3
            // 
            this.guna2Button3.BorderRadius = 12;
            this.guna2Button3.CheckedState.Parent = this.guna2Button3;
            this.guna2Button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2Button3.CustomImages.Parent = this.guna2Button3;
            this.guna2Button3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.guna2Button3.Font = new System.Drawing.Font("Poppins Black", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button3.ForeColor = System.Drawing.Color.White;
            this.guna2Button3.HoverState.BorderColor = System.Drawing.Color.Lime;
            this.guna2Button3.HoverState.CustomBorderColor = System.Drawing.Color.LightGreen;
            this.guna2Button3.HoverState.FillColor = System.Drawing.Color.Lime;
            this.guna2Button3.HoverState.Parent = this.guna2Button3;
            this.guna2Button3.Location = new System.Drawing.Point(1200, 82);
            this.guna2Button3.Name = "guna2Button3";
            this.guna2Button3.ShadowDecoration.Parent = this.guna2Button3;
            this.guna2Button3.Size = new System.Drawing.Size(135, 50);
            this.guna2Button3.TabIndex = 44;
            this.guna2Button3.Text = "Main page";
            this.guna2Button3.Click += new System.EventHandler(this.Guna2Button3_Click);
            // 
            // guna2Button4
            // 
            this.guna2Button4.BorderRadius = 12;
            this.guna2Button4.CheckedState.Parent = this.guna2Button4;
            this.guna2Button4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2Button4.CustomImages.Parent = this.guna2Button4;
            this.guna2Button4.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.guna2Button4.Font = new System.Drawing.Font("Poppins Black", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button4.ForeColor = System.Drawing.Color.White;
            this.guna2Button4.HoverState.BorderColor = System.Drawing.Color.Lime;
            this.guna2Button4.HoverState.CustomBorderColor = System.Drawing.Color.Lime;
            this.guna2Button4.HoverState.FillColor = System.Drawing.Color.Tomato;
            this.guna2Button4.HoverState.Parent = this.guna2Button4;
            this.guna2Button4.Location = new System.Drawing.Point(823, 82);
            this.guna2Button4.Name = "guna2Button4";
            this.guna2Button4.ShadowDecoration.Parent = this.guna2Button4;
            this.guna2Button4.Size = new System.Drawing.Size(135, 50);
            this.guna2Button4.TabIndex = 43;
            this.guna2Button4.Text = "D e l e t e";
            this.guna2Button4.Click += new System.EventHandler(this.Guna2Button4_Click);
            // 
            // guna2Button2
            // 
            this.guna2Button2.BorderRadius = 12;
            this.guna2Button2.CheckedState.Parent = this.guna2Button2;
            this.guna2Button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2Button2.CustomImages.Parent = this.guna2Button2;
            this.guna2Button2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.guna2Button2.Font = new System.Drawing.Font("Poppins Black", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button2.ForeColor = System.Drawing.Color.White;
            this.guna2Button2.HoverState.BorderColor = System.Drawing.Color.Lime;
            this.guna2Button2.HoverState.CustomBorderColor = System.Drawing.Color.Lime;
            this.guna2Button2.HoverState.FillColor = System.Drawing.Color.Tomato;
            this.guna2Button2.HoverState.Parent = this.guna2Button2;
            this.guna2Button2.Location = new System.Drawing.Point(670, 82);
            this.guna2Button2.Name = "guna2Button2";
            this.guna2Button2.ShadowDecoration.Parent = this.guna2Button2;
            this.guna2Button2.Size = new System.Drawing.Size(135, 50);
            this.guna2Button2.TabIndex = 42;
            this.guna2Button2.Text = "U p d a t e";
            this.guna2Button2.Click += new System.EventHandler(this.Guna2Button2_Click);
            // 
            // guna2Button1
            // 
            this.guna2Button1.BorderRadius = 12;
            this.guna2Button1.CheckedState.Parent = this.guna2Button1;
            this.guna2Button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2Button1.CustomImages.Parent = this.guna2Button1;
            this.guna2Button1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.guna2Button1.Font = new System.Drawing.Font("Poppins Black", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button1.ForeColor = System.Drawing.Color.White;
            this.guna2Button1.HoverState.BorderColor = System.Drawing.Color.Lime;
            this.guna2Button1.HoverState.CustomBorderColor = System.Drawing.Color.Lime;
            this.guna2Button1.HoverState.FillColor = System.Drawing.Color.Tomato;
            this.guna2Button1.HoverState.Parent = this.guna2Button1;
            this.guna2Button1.Location = new System.Drawing.Point(509, 82);
            this.guna2Button1.Name = "guna2Button1";
            this.guna2Button1.ShadowDecoration.Parent = this.guna2Button1;
            this.guna2Button1.Size = new System.Drawing.Size(135, 50);
            this.guna2Button1.TabIndex = 41;
            this.guna2Button1.Text = "s a v e";
            this.guna2Button1.Click += new System.EventHandler(this.Guna2Button1_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.serialnoDataGridViewTextBoxColumn,
            this.sandernameDataGridViewTextBoxColumn,
            this.sandernumberDataGridViewTextBoxColumn,
            this.recievernameDataGridViewTextBoxColumn,
            this.recievernumberDataGridViewTextBoxColumn,
            this.gongToDataGridViewTextBoxColumn,
            this.formtoDataGridViewTextBoxColumn,
            this.quantityDataGridViewTextBoxColumn,
            this.pirceDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.cargoBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(430, 216);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(940, 377);
            this.dataGridView1.TabIndex = 48;
            // 
            // serialnoDataGridViewTextBoxColumn
            // 
            this.serialnoDataGridViewTextBoxColumn.DataPropertyName = "Serialno";
            this.serialnoDataGridViewTextBoxColumn.HeaderText = "Serialno";
            this.serialnoDataGridViewTextBoxColumn.Name = "serialnoDataGridViewTextBoxColumn";
            // 
            // sandernameDataGridViewTextBoxColumn
            // 
            this.sandernameDataGridViewTextBoxColumn.DataPropertyName = "Sandername";
            this.sandernameDataGridViewTextBoxColumn.HeaderText = "Sandername";
            this.sandernameDataGridViewTextBoxColumn.Name = "sandernameDataGridViewTextBoxColumn";
            // 
            // sandernumberDataGridViewTextBoxColumn
            // 
            this.sandernumberDataGridViewTextBoxColumn.DataPropertyName = "sandernumber";
            this.sandernumberDataGridViewTextBoxColumn.HeaderText = "sandernumber";
            this.sandernumberDataGridViewTextBoxColumn.Name = "sandernumberDataGridViewTextBoxColumn";
            // 
            // recievernameDataGridViewTextBoxColumn
            // 
            this.recievernameDataGridViewTextBoxColumn.DataPropertyName = "Recievername";
            this.recievernameDataGridViewTextBoxColumn.HeaderText = "Recievername";
            this.recievernameDataGridViewTextBoxColumn.Name = "recievernameDataGridViewTextBoxColumn";
            // 
            // recievernumberDataGridViewTextBoxColumn
            // 
            this.recievernumberDataGridViewTextBoxColumn.DataPropertyName = "Recievernumber";
            this.recievernumberDataGridViewTextBoxColumn.HeaderText = "Recievernumber";
            this.recievernumberDataGridViewTextBoxColumn.Name = "recievernumberDataGridViewTextBoxColumn";
            // 
            // gongToDataGridViewTextBoxColumn
            // 
            this.gongToDataGridViewTextBoxColumn.DataPropertyName = "GongTo";
            this.gongToDataGridViewTextBoxColumn.HeaderText = "GongTo";
            this.gongToDataGridViewTextBoxColumn.Name = "gongToDataGridViewTextBoxColumn";
            // 
            // formtoDataGridViewTextBoxColumn
            // 
            this.formtoDataGridViewTextBoxColumn.DataPropertyName = "Formto";
            this.formtoDataGridViewTextBoxColumn.HeaderText = "Formto";
            this.formtoDataGridViewTextBoxColumn.Name = "formtoDataGridViewTextBoxColumn";
            // 
            // quantityDataGridViewTextBoxColumn
            // 
            this.quantityDataGridViewTextBoxColumn.DataPropertyName = "Quantity";
            this.quantityDataGridViewTextBoxColumn.HeaderText = "Quantity";
            this.quantityDataGridViewTextBoxColumn.Name = "quantityDataGridViewTextBoxColumn";
            // 
            // pirceDataGridViewTextBoxColumn
            // 
            this.pirceDataGridViewTextBoxColumn.DataPropertyName = "Pirce";
            this.pirceDataGridViewTextBoxColumn.HeaderText = "Pirce";
            this.pirceDataGridViewTextBoxColumn.Name = "pirceDataGridViewTextBoxColumn";
            // 
            // cargoBindingSource
            // 
            this.cargoBindingSource.DataMember = "Cargo";
            this.cargoBindingSource.DataSource = this.sahalTLDBDataSet1;
            // 
            // sahalTLDBDataSet1
            // 
            this.sahalTLDBDataSet1.DataSetName = "SahalTLDBDataSet1";
            this.sahalTLDBDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // cargoTableAdapter
            // 
            this.cargoTableAdapter.ClearBeforeFill = true;
            // 
            // guna2Button6
            // 
            this.guna2Button6.BorderRadius = 12;
            this.guna2Button6.CheckedState.Parent = this.guna2Button6;
            this.guna2Button6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2Button6.CustomImages.Parent = this.guna2Button6;
            this.guna2Button6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.guna2Button6.Font = new System.Drawing.Font("Poppins Black", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button6.ForeColor = System.Drawing.Color.White;
            this.guna2Button6.HoverState.BorderColor = System.Drawing.Color.Lime;
            this.guna2Button6.HoverState.CustomBorderColor = System.Drawing.Color.Lime;
            this.guna2Button6.HoverState.FillColor = System.Drawing.Color.Red;
            this.guna2Button6.HoverState.Parent = this.guna2Button6;
            this.guna2Button6.Location = new System.Drawing.Point(998, 82);
            this.guna2Button6.Name = "guna2Button6";
            this.guna2Button6.ShadowDecoration.Parent = this.guna2Button6;
            this.guna2Button6.Size = new System.Drawing.Size(135, 50);
            this.guna2Button6.TabIndex = 49;
            this.guna2Button6.Text = "C l e a r";
            this.guna2Button6.Click += new System.EventHandler(this.Guna2Button6_Click);
            // 
            // guna2Button7
            // 
            this.guna2Button7.BorderRadius = 12;
            this.guna2Button7.CheckedState.Parent = this.guna2Button7;
            this.guna2Button7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2Button7.CustomImages.Parent = this.guna2Button7;
            this.guna2Button7.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.guna2Button7.Font = new System.Drawing.Font("Poppins Black", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button7.ForeColor = System.Drawing.Color.White;
            this.guna2Button7.HoverState.BorderColor = System.Drawing.Color.Lime;
            this.guna2Button7.HoverState.CustomBorderColor = System.Drawing.Color.LightGreen;
            this.guna2Button7.HoverState.FillColor = System.Drawing.Color.Yellow;
            this.guna2Button7.HoverState.Parent = this.guna2Button7;
            this.guna2Button7.Location = new System.Drawing.Point(1200, 151);
            this.guna2Button7.Name = "guna2Button7";
            this.guna2Button7.ShadowDecoration.Parent = this.guna2Button7;
            this.guna2Button7.Size = new System.Drawing.Size(135, 50);
            this.guna2Button7.TabIndex = 50;
            this.guna2Button7.Text = "R e p o r t";
            this.guna2Button7.Click += new System.EventHandler(this.Guna2Button7_Click);
            // 
            // Cargo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1370, 604);
            this.Controls.Add(this.guna2Button7);
            this.Controls.Add(this.guna2Button6);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.guna2Button5);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.txtPsid);
            this.Controls.Add(this.guna2Button3);
            this.Controls.Add(this.guna2Button4);
            this.Controls.Add(this.guna2Button2);
            this.Controls.Add(this.guna2Button1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.txtPrice);
            this.Controls.Add(this.txtQuantity);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txtForm);
            this.Controls.Add(this.txtTO);
            this.Controls.Add(this.txtRecievernumber);
            this.Controls.Add(this.txtRecievername);
            this.Controls.Add(this.txtsandernumber);
            this.Controls.Add(this.txtsandername);
            this.Controls.Add(this.txtSerialno);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Name = "Cargo";
            this.Text = "Cargo";
            this.Load += new System.EventHandler(this.Cargo_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cargoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sahalTLDBDataSet1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2TextBox txtPrice;
        private Guna.UI2.WinForms.Guna2TextBox txtQuantity;
        private System.Windows.Forms.Label label9;
        private Guna.UI2.WinForms.Guna2TextBox txtForm;
        private Guna.UI2.WinForms.Guna2TextBox txtTO;
        private Guna.UI2.WinForms.Guna2TextBox txtRecievernumber;
        private Guna.UI2.WinForms.Guna2TextBox txtRecievername;
        private Guna.UI2.WinForms.Guna2TextBox txtsandernumber;
        private Guna.UI2.WinForms.Guna2TextBox txtsandername;
        private Guna.UI2.WinForms.Guna2TextBox txtSerialno;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2Button guna2Button5;
        private System.Windows.Forms.Label label11;
        private Guna.UI2.WinForms.Guna2TextBox txtPsid;
        private Guna.UI2.WinForms.Guna2Button guna2Button3;
        private Guna.UI2.WinForms.Guna2Button guna2Button4;
        private Guna.UI2.WinForms.Guna2Button guna2Button2;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private SahalTLDBDataSet1 sahalTLDBDataSet1;
        private System.Windows.Forms.BindingSource cargoBindingSource;
        private SahalTLDBDataSet1TableAdapters.CargoTableAdapter cargoTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn serialnoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sandernameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sandernumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn recievernameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn recievernumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gongToDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn formtoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn quantityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pirceDataGridViewTextBoxColumn;
        private Guna.UI2.WinForms.Guna2Button guna2Button6;
        private Guna.UI2.WinForms.Guna2Button guna2Button7;
    }
}