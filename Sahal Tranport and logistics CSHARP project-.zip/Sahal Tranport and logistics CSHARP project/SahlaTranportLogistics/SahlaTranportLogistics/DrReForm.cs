﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SahlaTranportLogistics
{
    public partial class DrReForm : Form
    {
        public DrReForm()
        {
            InitializeComponent();
        }

        private void DrReForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'SahalTLDBDataSet2.Driver' table. You can move, or remove it, as needed.
            this.DriverTableAdapter.Fill(this.SahalTLDBDataSet2.Driver);

            this.reportViewer1.RefreshReport();
        }

        private void ReportViewer1_Load(object sender, EventArgs e)
        {

        }
    }
}
