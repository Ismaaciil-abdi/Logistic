﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SahlaTranportLogistics
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void Singup_Click(object sender, EventArgs e)
        {
            SingUp mn = new SingUp();
            mn.Show();
            this.Hide();
        }

        private void PictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void Guna2CheckBox1_CheckedChanged(object sender, EventArgs e)
        {
           
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void Guna2Button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=HP\ISMAIL;Initial Catalog=SahalTLDB;Integrated Security=True");
            con.Open();

            {
                string str = "SELECT UserName FROM Register WHERE Username = '" + txtusername.Text + "' and Pass = '" + txtpassword.Text + "'";
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataReader dr;
                dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    this.Visible = false;
                    MainPage obj2 = new MainPage();
                    obj2.ShowDialog();
                }
                else
                {
                    MessageBox.Show("Invalid username or Password.");
                }
            }


        }

        private void Label6_Click(object sender, EventArgs e)
        {

        }

        private void Txtusername_TextChanged(object sender, EventArgs e)
        {

        }

        private void Txtpassword_TextChanged(object sender, EventArgs e)
        {

        }

        private void Label2_Click(object sender, EventArgs e)
        {
            forgetpass mr = new forgetpass();
            mr.Show();
            this.Hide();
        }
    }
}
