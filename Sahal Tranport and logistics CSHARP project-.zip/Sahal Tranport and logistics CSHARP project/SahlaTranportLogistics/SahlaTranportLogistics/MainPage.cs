﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SahlaTranportLogistics
{
    public partial class MainPage : Form
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void Label5_Click(object sender, EventArgs e)
        {

        }

        private void Label2_Click(object sender, EventArgs e)
        {

        }

        private void Guna2Button3_Click(object sender, EventArgs e)
        {
            Driver fr = new Driver();
            fr.Show();
            this.Hide();
        }

        private void Guna2Button1_Click(object sender, EventArgs e)
        {
            Passangers mr = new Passangers();
            mr.Show();
            this.Close();
        }

        private void Guna2Button2_Click(object sender, EventArgs e)
        {
            Cargo mr = new Cargo();
            mr.Show();
            this.Hide();
        }

        private void Guna2Button4_Click(object sender, EventArgs e)
        {
            Manager fr = new Manager();
            fr.Show();
            this.Close();

        }

        private void Guna2Button5_Click(object sender, EventArgs e)
        {
            Adminstration fr = new Adminstration();
            fr.Show();
            this.Close();

        }

        private void PictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void PictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void Guna2Button6_Click(object sender, EventArgs e)
        {
            DeloperSitting fr = new DeloperSitting();
            fr.Show();

        }
    }
}
