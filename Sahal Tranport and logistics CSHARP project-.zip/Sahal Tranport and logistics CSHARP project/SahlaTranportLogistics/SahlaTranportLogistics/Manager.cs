﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SahlaTranportLogistics
{
    public partial class Manager : Form
    {
        public Manager()
        {
            InitializeComponent();
        }


        private void DisplayData()
        {
            SqlConnection con = new SqlConnection(@"Data Source=HP\ISMAIL;Initial Catalog=SahalTLDB;Integrated Security=True");
            SqlDataAdapter adapt;
            con.Open();
            DataTable dt = new DataTable();
            adapt = new SqlDataAdapter("select * from Passanger", con);
            adapt.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }

        private void Guna2Button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=HP\ISMAIL;Initial Catalog=SahalTLDB;Integrated Security=True");
            con.Open();
            try
            {
                string str = " INSERT INTO Manager(MID,MName,MBranch,Salary,TimeWork,Yearlyentery) VALUES('" + txtMID.Text + "','" + txtMN.Text + "' ,'" + txtB.Text + "' ,'" + txtS.Text + "' ,'" + txtT.Text + "','" + txtY.Text + "'); ";
                SqlCommand cmd = new SqlCommand(str, con);
                cmd.ExecuteNonQuery();
                string str1 = "select max(MID) from Manager ;";
                SqlCommand cmd1 = new SqlCommand(str1, con);
                SqlDataReader dr = cmd1.ExecuteReader();
                if (dr.Read())
                {
                    MessageBox.Show("Successfully Saved. ");
                }
            }
            catch (SqlException excep)
            {
                MessageBox.Show(excep.Message);
            }
            con.Close();
            DisplayData();

        }

        private void Guna2Button2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=HP\ISMAIL;Initial Catalog=SahalTLDB;Integrated Security=True");
            SqlCommand cmd;
            if (txtMID.Text != "" && txtMN.Text != "" && txtB.Text != "" && txtS.Text != "" && txtT.Text != "" && txtY.Text != "")
            {
                cmd = new SqlCommand("UPDATE Manager set MID=@MID, MName=@MName,  MBranch=@MBranch, Salary=@Salary, TimeWork=@TimeWork, Yearlyentery=@Yearlyentery  where MID=@MID", con);
                con.Open();

                cmd.Parameters.AddWithValue("@MID", txtMID.Text);
                cmd.Parameters.AddWithValue("@MName", txtMN.Text);
                cmd.Parameters.AddWithValue("@MBranch", txtB.Text);
                cmd.Parameters.AddWithValue("@Salary", txtS.Text);
                cmd.Parameters.AddWithValue("@TimeWork", txtT.Text);
                cmd.Parameters.AddWithValue("@Yearlyentery", txtY.Text);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Record Updated");
                con.Close();
                DisplayData();
            }
            else
            {
                MessageBox.Show("Please Select Record to Update");
            }
            
        }

        private void Manager_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'sahalTLDBDataSet3.Manager' table. You can move, or remove it, as needed.
            this.managerTableAdapter.Fill(this.sahalTLDBDataSet3.Manager);

        }

        private void Guna2Button4_Click(object sender, EventArgs e)
        {

            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=HP\ISMAIL;Initial Catalog=SahalTLDB;Integrated Security=True");
                con.Open();

                string str = "DELETE FROM Manager WHERE MID = '" + txtPsid.Text + "'";

                SqlCommand cmd = new SqlCommand(str, con);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Record Delete Successfully");

                using (SqlConnection newcon = new SqlConnection(@"Data Source=HP\ISMAIL;Initial Catalog=SahalTLDB;Integrated Security=True"))
                {
                    string str1 = @"SELECT * from Manager";
                    SqlCommand cmd1 = new SqlCommand(str1, newcon);
                    SqlDataAdapter da = new SqlDataAdapter(cmd1);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dataGridView1.DataSource = new BindingSource(dt, null);

                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                MessageBox.Show("Please Enter Passanger Id");
            }
            DisplayData();

        }

        private void Guna2Button3_Click(object sender, EventArgs e)
        {
            MainPage fr = new MainPage();
            fr.Show();
            this.Close();

        }

        private void Guna2Button5_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=HP\ISMAIL;Initial Catalog=SahalTLDB;Integrated Security=True");
                {
                    string str1 = @"SELECT * from Manager where MID = '" + txtPsid.Text + "'";
                    SqlCommand cmd1 = new SqlCommand(str1, con);
                    SqlDataAdapter da = new SqlDataAdapter(cmd1);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dataGridView1.DataSource = new BindingSource(dt, null);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                MessageBox.Show("Please Enter Passanger ID");
            }
        }

        private void Guna2Button6_Click(object sender, EventArgs e)
        {
            txtMID.Text = "";
            txtMN.Text = "";
            txtY.Text="";
            txtS.Text="";
            txtB.Text="";
            txtT.Text = "";


        }

        private void DataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void PictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void Guna2Button7_Click(object sender, EventArgs e)
        {
            
        }

        private void Guna2Button7_Click_1(object sender, EventArgs e)
        {
            
        }

        private void Guna2Button7_Click_2(object sender, EventArgs e)
        {
            MngRFrom fr = new MngRFrom();
            fr.Show();
            

        }
    }
}
