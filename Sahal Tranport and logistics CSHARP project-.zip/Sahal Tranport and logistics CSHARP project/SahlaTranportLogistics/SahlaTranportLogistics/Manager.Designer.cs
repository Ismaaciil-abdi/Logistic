﻿namespace SahlaTranportLogistics
{
    partial class Manager
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.guna2Button6 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button5 = new Guna.UI2.WinForms.Guna2Button();
            this.txtPsid = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2Button3 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button4 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button2 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            this.txtY = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtT = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtS = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtB = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtMN = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtMID = new Guna.UI2.WinForms.Guna2TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.mIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mBranchDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.salaryDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.timeWorkDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.yearlyenteryDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.managerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sahalTLDBDataSet3 = new SahlaTranportLogistics.SahalTLDBDataSet3();
            this.managerTableAdapter = new SahlaTranportLogistics.SahalTLDBDataSet3TableAdapters.ManagerTableAdapter();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.guna2Button7 = new Guna.UI2.WinForms.Guna2Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.managerBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sahalTLDBDataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // guna2Button6
            // 
            this.guna2Button6.BorderRadius = 12;
            this.guna2Button6.CheckedState.Parent = this.guna2Button6;
            this.guna2Button6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2Button6.CustomImages.Parent = this.guna2Button6;
            this.guna2Button6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.guna2Button6.Font = new System.Drawing.Font("Poppins Black", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button6.ForeColor = System.Drawing.Color.White;
            this.guna2Button6.HoverState.BorderColor = System.Drawing.Color.Lime;
            this.guna2Button6.HoverState.CustomBorderColor = System.Drawing.Color.Lime;
            this.guna2Button6.HoverState.FillColor = System.Drawing.Color.Red;
            this.guna2Button6.HoverState.Parent = this.guna2Button6;
            this.guna2Button6.Location = new System.Drawing.Point(1001, 93);
            this.guna2Button6.Name = "guna2Button6";
            this.guna2Button6.ShadowDecoration.Parent = this.guna2Button6;
            this.guna2Button6.Size = new System.Drawing.Size(135, 50);
            this.guna2Button6.TabIndex = 74;
            this.guna2Button6.Text = "C l e a r";
            this.guna2Button6.Click += new System.EventHandler(this.Guna2Button6_Click);
            // 
            // guna2Button5
            // 
            this.guna2Button5.BorderRadius = 12;
            this.guna2Button5.CheckedState.Parent = this.guna2Button5;
            this.guna2Button5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2Button5.CustomImages.Parent = this.guna2Button5;
            this.guna2Button5.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.guna2Button5.Font = new System.Drawing.Font("Poppins Black", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button5.ForeColor = System.Drawing.Color.White;
            this.guna2Button5.HoverState.BorderColor = System.Drawing.Color.Lime;
            this.guna2Button5.HoverState.CustomBorderColor = System.Drawing.Color.Lime;
            this.guna2Button5.HoverState.FillColor = System.Drawing.Color.Tomato;
            this.guna2Button5.HoverState.Parent = this.guna2Button5;
            this.guna2Button5.Location = new System.Drawing.Point(512, 162);
            this.guna2Button5.Name = "guna2Button5";
            this.guna2Button5.ShadowDecoration.Parent = this.guna2Button5;
            this.guna2Button5.Size = new System.Drawing.Size(135, 50);
            this.guna2Button5.TabIndex = 73;
            this.guna2Button5.Text = "s e a r c h";
            this.guna2Button5.Click += new System.EventHandler(this.Guna2Button5_Click);
            // 
            // txtPsid
            // 
            this.txtPsid.BorderRadius = 12;
            this.txtPsid.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtPsid.DefaultText = "";
            this.txtPsid.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtPsid.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtPsid.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtPsid.DisabledState.Parent = this.txtPsid;
            this.txtPsid.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtPsid.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.txtPsid.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtPsid.FocusedState.Parent = this.txtPsid;
            this.txtPsid.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold);
            this.txtPsid.ForeColor = System.Drawing.Color.White;
            this.txtPsid.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtPsid.HoverState.Parent = this.txtPsid;
            this.txtPsid.Location = new System.Drawing.Point(673, 162);
            this.txtPsid.Margin = new System.Windows.Forms.Padding(4);
            this.txtPsid.Name = "txtPsid";
            this.txtPsid.PasswordChar = '\0';
            this.txtPsid.PlaceholderText = "";
            this.txtPsid.SelectedText = "";
            this.txtPsid.ShadowDecoration.Parent = this.txtPsid;
            this.txtPsid.Size = new System.Drawing.Size(463, 44);
            this.txtPsid.TabIndex = 72;
            // 
            // guna2Button3
            // 
            this.guna2Button3.BorderRadius = 12;
            this.guna2Button3.CheckedState.Parent = this.guna2Button3;
            this.guna2Button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2Button3.CustomImages.Parent = this.guna2Button3;
            this.guna2Button3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.guna2Button3.Font = new System.Drawing.Font("Poppins Black", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button3.ForeColor = System.Drawing.Color.White;
            this.guna2Button3.HoverState.BorderColor = System.Drawing.Color.Lime;
            this.guna2Button3.HoverState.CustomBorderColor = System.Drawing.Color.LightGreen;
            this.guna2Button3.HoverState.FillColor = System.Drawing.Color.Lime;
            this.guna2Button3.HoverState.Parent = this.guna2Button3;
            this.guna2Button3.Location = new System.Drawing.Point(1203, 93);
            this.guna2Button3.Name = "guna2Button3";
            this.guna2Button3.ShadowDecoration.Parent = this.guna2Button3;
            this.guna2Button3.Size = new System.Drawing.Size(135, 50);
            this.guna2Button3.TabIndex = 71;
            this.guna2Button3.Text = "Main page";
            this.guna2Button3.Click += new System.EventHandler(this.Guna2Button3_Click);
            // 
            // guna2Button4
            // 
            this.guna2Button4.BorderRadius = 12;
            this.guna2Button4.CheckedState.Parent = this.guna2Button4;
            this.guna2Button4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2Button4.CustomImages.Parent = this.guna2Button4;
            this.guna2Button4.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.guna2Button4.Font = new System.Drawing.Font("Poppins Black", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button4.ForeColor = System.Drawing.Color.White;
            this.guna2Button4.HoverState.BorderColor = System.Drawing.Color.Lime;
            this.guna2Button4.HoverState.CustomBorderColor = System.Drawing.Color.Lime;
            this.guna2Button4.HoverState.FillColor = System.Drawing.Color.Tomato;
            this.guna2Button4.HoverState.Parent = this.guna2Button4;
            this.guna2Button4.Location = new System.Drawing.Point(826, 93);
            this.guna2Button4.Name = "guna2Button4";
            this.guna2Button4.ShadowDecoration.Parent = this.guna2Button4;
            this.guna2Button4.Size = new System.Drawing.Size(135, 50);
            this.guna2Button4.TabIndex = 70;
            this.guna2Button4.Text = "D e l e t e";
            this.guna2Button4.Click += new System.EventHandler(this.Guna2Button4_Click);
            // 
            // guna2Button2
            // 
            this.guna2Button2.BorderRadius = 12;
            this.guna2Button2.CheckedState.Parent = this.guna2Button2;
            this.guna2Button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2Button2.CustomImages.Parent = this.guna2Button2;
            this.guna2Button2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.guna2Button2.Font = new System.Drawing.Font("Poppins Black", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button2.ForeColor = System.Drawing.Color.White;
            this.guna2Button2.HoverState.BorderColor = System.Drawing.Color.Lime;
            this.guna2Button2.HoverState.CustomBorderColor = System.Drawing.Color.Lime;
            this.guna2Button2.HoverState.FillColor = System.Drawing.Color.Tomato;
            this.guna2Button2.HoverState.Parent = this.guna2Button2;
            this.guna2Button2.Location = new System.Drawing.Point(673, 93);
            this.guna2Button2.Name = "guna2Button2";
            this.guna2Button2.ShadowDecoration.Parent = this.guna2Button2;
            this.guna2Button2.Size = new System.Drawing.Size(135, 50);
            this.guna2Button2.TabIndex = 69;
            this.guna2Button2.Text = "U p d a t e";
            this.guna2Button2.Click += new System.EventHandler(this.Guna2Button2_Click);
            // 
            // guna2Button1
            // 
            this.guna2Button1.BorderRadius = 12;
            this.guna2Button1.CheckedState.Parent = this.guna2Button1;
            this.guna2Button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2Button1.CustomImages.Parent = this.guna2Button1;
            this.guna2Button1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.guna2Button1.Font = new System.Drawing.Font("Poppins Black", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button1.ForeColor = System.Drawing.Color.White;
            this.guna2Button1.HoverState.BorderColor = System.Drawing.Color.Lime;
            this.guna2Button1.HoverState.CustomBorderColor = System.Drawing.Color.Lime;
            this.guna2Button1.HoverState.FillColor = System.Drawing.Color.Tomato;
            this.guna2Button1.HoverState.Parent = this.guna2Button1;
            this.guna2Button1.Location = new System.Drawing.Point(512, 93);
            this.guna2Button1.Name = "guna2Button1";
            this.guna2Button1.ShadowDecoration.Parent = this.guna2Button1;
            this.guna2Button1.Size = new System.Drawing.Size(135, 50);
            this.guna2Button1.TabIndex = 68;
            this.guna2Button1.Text = "s a v e";
            this.guna2Button1.Click += new System.EventHandler(this.Guna2Button1_Click);
            // 
            // txtY
            // 
            this.txtY.BorderRadius = 12;
            this.txtY.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtY.DefaultText = "";
            this.txtY.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtY.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtY.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtY.DisabledState.Parent = this.txtY;
            this.txtY.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtY.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.txtY.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtY.FocusedState.Parent = this.txtY;
            this.txtY.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold);
            this.txtY.ForeColor = System.Drawing.Color.White;
            this.txtY.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtY.HoverState.Parent = this.txtY;
            this.txtY.Location = new System.Drawing.Point(197, 352);
            this.txtY.Margin = new System.Windows.Forms.Padding(4);
            this.txtY.Name = "txtY";
            this.txtY.PasswordChar = '\0';
            this.txtY.PlaceholderText = "";
            this.txtY.SelectedText = "";
            this.txtY.ShadowDecoration.Parent = this.txtY;
            this.txtY.Size = new System.Drawing.Size(229, 44);
            this.txtY.TabIndex = 63;
            // 
            // txtT
            // 
            this.txtT.BorderRadius = 12;
            this.txtT.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtT.DefaultText = "";
            this.txtT.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtT.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtT.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtT.DisabledState.Parent = this.txtT;
            this.txtT.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtT.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.txtT.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtT.FocusedState.Parent = this.txtT;
            this.txtT.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold);
            this.txtT.ForeColor = System.Drawing.Color.White;
            this.txtT.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtT.HoverState.Parent = this.txtT;
            this.txtT.Location = new System.Drawing.Point(197, 300);
            this.txtT.Margin = new System.Windows.Forms.Padding(4);
            this.txtT.Name = "txtT";
            this.txtT.PasswordChar = '\0';
            this.txtT.PlaceholderText = "";
            this.txtT.SelectedText = "";
            this.txtT.ShadowDecoration.Parent = this.txtT;
            this.txtT.Size = new System.Drawing.Size(229, 44);
            this.txtT.TabIndex = 62;
            // 
            // txtS
            // 
            this.txtS.BorderRadius = 12;
            this.txtS.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtS.DefaultText = "";
            this.txtS.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtS.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtS.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtS.DisabledState.Parent = this.txtS;
            this.txtS.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtS.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.txtS.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtS.FocusedState.Parent = this.txtS;
            this.txtS.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold);
            this.txtS.ForeColor = System.Drawing.Color.White;
            this.txtS.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtS.HoverState.Parent = this.txtS;
            this.txtS.Location = new System.Drawing.Point(197, 249);
            this.txtS.Margin = new System.Windows.Forms.Padding(4);
            this.txtS.Name = "txtS";
            this.txtS.PasswordChar = '\0';
            this.txtS.PlaceholderText = "";
            this.txtS.SelectedText = "";
            this.txtS.ShadowDecoration.Parent = this.txtS;
            this.txtS.Size = new System.Drawing.Size(229, 44);
            this.txtS.TabIndex = 61;
            // 
            // txtB
            // 
            this.txtB.BorderRadius = 12;
            this.txtB.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtB.DefaultText = "";
            this.txtB.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtB.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtB.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtB.DisabledState.Parent = this.txtB;
            this.txtB.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtB.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.txtB.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtB.FocusedState.Parent = this.txtB;
            this.txtB.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold);
            this.txtB.ForeColor = System.Drawing.Color.White;
            this.txtB.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtB.HoverState.Parent = this.txtB;
            this.txtB.Location = new System.Drawing.Point(197, 197);
            this.txtB.Margin = new System.Windows.Forms.Padding(4);
            this.txtB.Name = "txtB";
            this.txtB.PasswordChar = '\0';
            this.txtB.PlaceholderText = "";
            this.txtB.SelectedText = "";
            this.txtB.ShadowDecoration.Parent = this.txtB;
            this.txtB.Size = new System.Drawing.Size(229, 44);
            this.txtB.TabIndex = 60;
            // 
            // txtMN
            // 
            this.txtMN.BorderRadius = 12;
            this.txtMN.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtMN.DefaultText = "";
            this.txtMN.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtMN.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtMN.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtMN.DisabledState.Parent = this.txtMN;
            this.txtMN.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtMN.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.txtMN.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtMN.FocusedState.Parent = this.txtMN;
            this.txtMN.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold);
            this.txtMN.ForeColor = System.Drawing.Color.White;
            this.txtMN.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtMN.HoverState.Parent = this.txtMN;
            this.txtMN.Location = new System.Drawing.Point(197, 143);
            this.txtMN.Margin = new System.Windows.Forms.Padding(4);
            this.txtMN.Name = "txtMN";
            this.txtMN.PasswordChar = '\0';
            this.txtMN.PlaceholderText = "";
            this.txtMN.SelectedText = "";
            this.txtMN.ShadowDecoration.Parent = this.txtMN;
            this.txtMN.Size = new System.Drawing.Size(229, 44);
            this.txtMN.TabIndex = 59;
            // 
            // txtMID
            // 
            this.txtMID.BorderRadius = 12;
            this.txtMID.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtMID.DefaultText = "";
            this.txtMID.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtMID.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtMID.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtMID.DisabledState.Parent = this.txtMID;
            this.txtMID.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtMID.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.txtMID.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtMID.FocusedState.Parent = this.txtMID;
            this.txtMID.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMID.ForeColor = System.Drawing.Color.White;
            this.txtMID.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtMID.HoverState.Parent = this.txtMID;
            this.txtMID.Location = new System.Drawing.Point(197, 90);
            this.txtMID.Margin = new System.Windows.Forms.Padding(4);
            this.txtMID.Name = "txtMID";
            this.txtMID.PasswordChar = '\0';
            this.txtMID.PlaceholderText = "";
            this.txtMID.SelectedText = "";
            this.txtMID.ShadowDecoration.Parent = this.txtMID;
            this.txtMID.Size = new System.Drawing.Size(229, 44);
            this.txtMID.TabIndex = 58;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Poppins", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(15, 357);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(148, 34);
            this.label7.TabIndex = 55;
            this.label7.Text = "Yearly enetry";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Poppins", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(15, 305);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(116, 34);
            this.label6.TabIndex = 54;
            this.label6.Text = "Time work";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Poppins", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(15, 254);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(79, 34);
            this.label5.TabIndex = 53;
            this.label5.Text = "Salary";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Poppins", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(15, 202);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(86, 34);
            this.label4.TabIndex = 52;
            this.label4.Text = "Branch";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Poppins", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(15, 148);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(170, 34);
            this.label3.TabIndex = 51;
            this.label3.Text = "Manager  name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Poppins", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(15, 95);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(128, 34);
            this.label2.TabIndex = 50;
            this.label2.Text = "Manager ID";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(1, 1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1370, 64);
            this.panel1.TabIndex = 75;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Poppins", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(549, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(275, 56);
            this.label1.TabIndex = 0;
            this.label1.Text = "Manager F orm";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.mIDDataGridViewTextBoxColumn,
            this.mNameDataGridViewTextBoxColumn,
            this.mBranchDataGridViewTextBoxColumn,
            this.salaryDataGridViewTextBoxColumn,
            this.timeWorkDataGridViewTextBoxColumn,
            this.yearlyenteryDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.managerBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(512, 227);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(645, 365);
            this.dataGridView1.TabIndex = 76;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DataGridView1_CellContentClick);
            // 
            // mIDDataGridViewTextBoxColumn
            // 
            this.mIDDataGridViewTextBoxColumn.DataPropertyName = "MID";
            this.mIDDataGridViewTextBoxColumn.HeaderText = "MID";
            this.mIDDataGridViewTextBoxColumn.Name = "mIDDataGridViewTextBoxColumn";
            // 
            // mNameDataGridViewTextBoxColumn
            // 
            this.mNameDataGridViewTextBoxColumn.DataPropertyName = "MName";
            this.mNameDataGridViewTextBoxColumn.HeaderText = "MName";
            this.mNameDataGridViewTextBoxColumn.Name = "mNameDataGridViewTextBoxColumn";
            // 
            // mBranchDataGridViewTextBoxColumn
            // 
            this.mBranchDataGridViewTextBoxColumn.DataPropertyName = "MBranch";
            this.mBranchDataGridViewTextBoxColumn.HeaderText = "MBranch";
            this.mBranchDataGridViewTextBoxColumn.Name = "mBranchDataGridViewTextBoxColumn";
            // 
            // salaryDataGridViewTextBoxColumn
            // 
            this.salaryDataGridViewTextBoxColumn.DataPropertyName = "Salary";
            this.salaryDataGridViewTextBoxColumn.HeaderText = "Salary";
            this.salaryDataGridViewTextBoxColumn.Name = "salaryDataGridViewTextBoxColumn";
            // 
            // timeWorkDataGridViewTextBoxColumn
            // 
            this.timeWorkDataGridViewTextBoxColumn.DataPropertyName = "TimeWork";
            this.timeWorkDataGridViewTextBoxColumn.HeaderText = "TimeWork";
            this.timeWorkDataGridViewTextBoxColumn.Name = "timeWorkDataGridViewTextBoxColumn";
            // 
            // yearlyenteryDataGridViewTextBoxColumn
            // 
            this.yearlyenteryDataGridViewTextBoxColumn.DataPropertyName = "Yearlyentery";
            this.yearlyenteryDataGridViewTextBoxColumn.HeaderText = "Yearlyentery";
            this.yearlyenteryDataGridViewTextBoxColumn.Name = "yearlyenteryDataGridViewTextBoxColumn";
            // 
            // managerBindingSource
            // 
            this.managerBindingSource.DataMember = "Manager";
            this.managerBindingSource.DataSource = this.sahalTLDBDataSet3;
            // 
            // sahalTLDBDataSet3
            // 
            this.sahalTLDBDataSet3.DataSetName = "SahalTLDBDataSet3";
            this.sahalTLDBDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // managerTableAdapter
            // 
            this.managerTableAdapter.ClearBeforeFill = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::SahlaTranportLogistics.Properties.Resources.Mask_Group_8;
            this.pictureBox1.Location = new System.Drawing.Point(1, 394);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(406, 254);
            this.pictureBox1.TabIndex = 77;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.PictureBox1_Click);
            // 
            // guna2Button7
            // 
            this.guna2Button7.BorderRadius = 12;
            this.guna2Button7.CheckedState.Parent = this.guna2Button7;
            this.guna2Button7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2Button7.CustomImages.Parent = this.guna2Button7;
            this.guna2Button7.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.guna2Button7.Font = new System.Drawing.Font("Poppins Black", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button7.ForeColor = System.Drawing.Color.White;
            this.guna2Button7.HoverState.BorderColor = System.Drawing.Color.Lime;
            this.guna2Button7.HoverState.CustomBorderColor = System.Drawing.Color.Yellow;
            this.guna2Button7.HoverState.FillColor = System.Drawing.Color.Yellow;
            this.guna2Button7.HoverState.Parent = this.guna2Button7;
            this.guna2Button7.Location = new System.Drawing.Point(1203, 156);
            this.guna2Button7.Name = "guna2Button7";
            this.guna2Button7.ShadowDecoration.Parent = this.guna2Button7;
            this.guna2Button7.Size = new System.Drawing.Size(135, 50);
            this.guna2Button7.TabIndex = 78;
            this.guna2Button7.Text = "R e p o r t";
            this.guna2Button7.Click += new System.EventHandler(this.Guna2Button7_Click_2);
            // 
            // Manager
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1370, 648);
            this.Controls.Add(this.guna2Button7);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.guna2Button6);
            this.Controls.Add(this.guna2Button5);
            this.Controls.Add(this.txtPsid);
            this.Controls.Add(this.guna2Button3);
            this.Controls.Add(this.guna2Button4);
            this.Controls.Add(this.guna2Button2);
            this.Controls.Add(this.guna2Button1);
            this.Controls.Add(this.txtY);
            this.Controls.Add(this.txtT);
            this.Controls.Add(this.txtS);
            this.Controls.Add(this.txtB);
            this.Controls.Add(this.txtMN);
            this.Controls.Add(this.txtMID);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Manager";
            this.Text = "Manager";
            this.Load += new System.EventHandler(this.Manager_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.managerBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sahalTLDBDataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2Button guna2Button6;
        private Guna.UI2.WinForms.Guna2Button guna2Button5;
        private Guna.UI2.WinForms.Guna2TextBox txtPsid;
        private Guna.UI2.WinForms.Guna2Button guna2Button3;
        private Guna.UI2.WinForms.Guna2Button guna2Button4;
        private Guna.UI2.WinForms.Guna2Button guna2Button2;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private Guna.UI2.WinForms.Guna2TextBox txtY;
        private Guna.UI2.WinForms.Guna2TextBox txtT;
        private Guna.UI2.WinForms.Guna2TextBox txtS;
        private Guna.UI2.WinForms.Guna2TextBox txtB;
        private Guna.UI2.WinForms.Guna2TextBox txtMN;
        private Guna.UI2.WinForms.Guna2TextBox txtMID;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private SahalTLDBDataSet3 sahalTLDBDataSet3;
        private System.Windows.Forms.BindingSource managerBindingSource;
        private SahalTLDBDataSet3TableAdapters.ManagerTableAdapter managerTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn mIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mBranchDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn salaryDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn timeWorkDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn yearlyenteryDataGridViewTextBoxColumn;
        private System.Windows.Forms.PictureBox pictureBox1;
        private Guna.UI2.WinForms.Guna2Button guna2Button7;
    }
}