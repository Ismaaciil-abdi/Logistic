﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SahlaTranportLogistics
{
    public partial class MngRFrom : Form
    {
        public MngRFrom()
        {
            InitializeComponent();
        }

        private void MngRFrom_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'SahalTLDBDataSet1.Cargo' table. You can move, or remove it, as needed.
            this.CargoTableAdapter.Fill(this.SahalTLDBDataSet1.Cargo);
            // TODO: This line of code loads data into the 'SahalTLDBDataSet3.Manager' table. You can move, or remove it, as needed.
            this.ManagerTableAdapter.Fill(this.SahalTLDBDataSet3.Manager);

            this.reportViewer1.RefreshReport();
        }

        private void ReportViewer1_Load(object sender, EventArgs e)
        {

        }
    }
}
