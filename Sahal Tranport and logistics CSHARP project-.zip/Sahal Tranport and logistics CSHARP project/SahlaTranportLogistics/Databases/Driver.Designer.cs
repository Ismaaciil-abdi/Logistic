﻿namespace SahlaTranportLogistics
{
    partial class Driver
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.serialnoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sandernameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sandernumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.recievernumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gongToDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.formtoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.quantityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pirceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.recievernameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtDriverID1 = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtDrivername = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtDriverLicien = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtDriversalary = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtDBno = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtAge = new Guna.UI2.WinForms.Guna2TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtDriverID = new System.Windows.Forms.Panel();
            this.guna2Button6 = new Guna.UI2.WinForms.Guna2Button();
            this.label11 = new System.Windows.Forms.Label();
            this.guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button2 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button4 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button3 = new Guna.UI2.WinForms.Guna2Button();
            this.txtPsid = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2Button5 = new Guna.UI2.WinForms.Guna2Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.driverIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.drivernameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.driverLicienDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.driversalaryDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.driverBusnoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ageDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.driverBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sahalTLDBDataSet2 = new SahlaTranportLogistics.SahalTLDBDataSet2();
            this.driverTableAdapter = new SahlaTranportLogistics.SahalTLDBDataSet2TableAdapters.DriverTableAdapter();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.txtDriverID.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.driverBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sahalTLDBDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // serialnoDataGridViewTextBoxColumn
            // 
            this.serialnoDataGridViewTextBoxColumn.DataPropertyName = "Serialno";
            this.serialnoDataGridViewTextBoxColumn.HeaderText = "Serialno";
            this.serialnoDataGridViewTextBoxColumn.Name = "serialnoDataGridViewTextBoxColumn";
            // 
            // sandernameDataGridViewTextBoxColumn
            // 
            this.sandernameDataGridViewTextBoxColumn.DataPropertyName = "Sandername";
            this.sandernameDataGridViewTextBoxColumn.HeaderText = "Sandername";
            this.sandernameDataGridViewTextBoxColumn.Name = "sandernameDataGridViewTextBoxColumn";
            // 
            // sandernumberDataGridViewTextBoxColumn
            // 
            this.sandernumberDataGridViewTextBoxColumn.DataPropertyName = "sandernumber";
            this.sandernumberDataGridViewTextBoxColumn.HeaderText = "sandernumber";
            this.sandernumberDataGridViewTextBoxColumn.Name = "sandernumberDataGridViewTextBoxColumn";
            // 
            // recievernumberDataGridViewTextBoxColumn
            // 
            this.recievernumberDataGridViewTextBoxColumn.DataPropertyName = "Recievernumber";
            this.recievernumberDataGridViewTextBoxColumn.HeaderText = "Recievernumber";
            this.recievernumberDataGridViewTextBoxColumn.Name = "recievernumberDataGridViewTextBoxColumn";
            // 
            // gongToDataGridViewTextBoxColumn
            // 
            this.gongToDataGridViewTextBoxColumn.DataPropertyName = "GongTo";
            this.gongToDataGridViewTextBoxColumn.HeaderText = "GongTo";
            this.gongToDataGridViewTextBoxColumn.Name = "gongToDataGridViewTextBoxColumn";
            // 
            // formtoDataGridViewTextBoxColumn
            // 
            this.formtoDataGridViewTextBoxColumn.DataPropertyName = "Formto";
            this.formtoDataGridViewTextBoxColumn.HeaderText = "Formto";
            this.formtoDataGridViewTextBoxColumn.Name = "formtoDataGridViewTextBoxColumn";
            // 
            // quantityDataGridViewTextBoxColumn
            // 
            this.quantityDataGridViewTextBoxColumn.DataPropertyName = "Quantity";
            this.quantityDataGridViewTextBoxColumn.HeaderText = "Quantity";
            this.quantityDataGridViewTextBoxColumn.Name = "quantityDataGridViewTextBoxColumn";
            // 
            // pirceDataGridViewTextBoxColumn
            // 
            this.pirceDataGridViewTextBoxColumn.DataPropertyName = "Pirce";
            this.pirceDataGridViewTextBoxColumn.HeaderText = "Pirce";
            this.pirceDataGridViewTextBoxColumn.Name = "pirceDataGridViewTextBoxColumn";
            // 
            // recievernameDataGridViewTextBoxColumn
            // 
            this.recievernameDataGridViewTextBoxColumn.DataPropertyName = "Recievername";
            this.recievernameDataGridViewTextBoxColumn.HeaderText = "Recievername";
            this.recievernameDataGridViewTextBoxColumn.Name = "recievernameDataGridViewTextBoxColumn";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Poppins", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(9, 173);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(99, 34);
            this.label2.TabIndex = 50;
            this.label2.Text = "Driver ID";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Poppins", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(9, 226);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(137, 34);
            this.label3.TabIndex = 51;
            this.label3.Text = "Driver name";
            this.label3.Click += new System.EventHandler(this.Label3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Poppins", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(9, 280);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(133, 34);
            this.label4.TabIndex = 52;
            this.label4.Text = "Driver licien";
            this.label4.Click += new System.EventHandler(this.Label4_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Poppins", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(9, 332);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(142, 34);
            this.label5.TabIndex = 53;
            this.label5.Text = "Driver salary";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Poppins", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(9, 384);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(106, 34);
            this.label6.TabIndex = 54;
            this.label6.Text = "D-Bus no";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Poppins", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(9, 436);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(54, 34);
            this.label7.TabIndex = 55;
            this.label7.Text = "Age";
            // 
            // txtDriverID1
            // 
            this.txtDriverID1.BorderRadius = 12;
            this.txtDriverID1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtDriverID1.DefaultText = "";
            this.txtDriverID1.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtDriverID1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtDriverID1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtDriverID1.DisabledState.Parent = this.txtDriverID1;
            this.txtDriverID1.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtDriverID1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.txtDriverID1.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtDriverID1.FocusedState.Parent = this.txtDriverID1;
            this.txtDriverID1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDriverID1.ForeColor = System.Drawing.Color.White;
            this.txtDriverID1.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtDriverID1.HoverState.Parent = this.txtDriverID1;
            this.txtDriverID1.Location = new System.Drawing.Point(191, 168);
            this.txtDriverID1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtDriverID1.Name = "txtDriverID1";
            this.txtDriverID1.PasswordChar = '\0';
            this.txtDriverID1.PlaceholderText = "";
            this.txtDriverID1.SelectedText = "";
            this.txtDriverID1.ShadowDecoration.Parent = this.txtDriverID1;
            this.txtDriverID1.Size = new System.Drawing.Size(229, 44);
            this.txtDriverID1.TabIndex = 58;
            this.txtDriverID1.TextChanged += new System.EventHandler(this.TxtSerialno_TextChanged);
            // 
            // txtDrivername
            // 
            this.txtDrivername.BorderRadius = 12;
            this.txtDrivername.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtDrivername.DefaultText = "";
            this.txtDrivername.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtDrivername.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtDrivername.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtDrivername.DisabledState.Parent = this.txtDrivername;
            this.txtDrivername.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtDrivername.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.txtDrivername.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtDrivername.FocusedState.Parent = this.txtDrivername;
            this.txtDrivername.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDrivername.ForeColor = System.Drawing.Color.White;
            this.txtDrivername.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtDrivername.HoverState.Parent = this.txtDrivername;
            this.txtDrivername.Location = new System.Drawing.Point(191, 221);
            this.txtDrivername.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtDrivername.Name = "txtDrivername";
            this.txtDrivername.PasswordChar = '\0';
            this.txtDrivername.PlaceholderText = "";
            this.txtDrivername.SelectedText = "";
            this.txtDrivername.ShadowDecoration.Parent = this.txtDrivername;
            this.txtDrivername.Size = new System.Drawing.Size(229, 44);
            this.txtDrivername.TabIndex = 59;
            // 
            // txtDriverLicien
            // 
            this.txtDriverLicien.BorderRadius = 12;
            this.txtDriverLicien.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtDriverLicien.DefaultText = "";
            this.txtDriverLicien.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtDriverLicien.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtDriverLicien.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtDriverLicien.DisabledState.Parent = this.txtDriverLicien;
            this.txtDriverLicien.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtDriverLicien.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.txtDriverLicien.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtDriverLicien.FocusedState.Parent = this.txtDriverLicien;
            this.txtDriverLicien.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDriverLicien.ForeColor = System.Drawing.Color.White;
            this.txtDriverLicien.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtDriverLicien.HoverState.Parent = this.txtDriverLicien;
            this.txtDriverLicien.Location = new System.Drawing.Point(191, 275);
            this.txtDriverLicien.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtDriverLicien.Name = "txtDriverLicien";
            this.txtDriverLicien.PasswordChar = '\0';
            this.txtDriverLicien.PlaceholderText = "";
            this.txtDriverLicien.SelectedText = "";
            this.txtDriverLicien.ShadowDecoration.Parent = this.txtDriverLicien;
            this.txtDriverLicien.Size = new System.Drawing.Size(229, 44);
            this.txtDriverLicien.TabIndex = 60;
            this.txtDriverLicien.TextChanged += new System.EventHandler(this.TxtDriverLicien_TextChanged);
            // 
            // txtDriversalary
            // 
            this.txtDriversalary.BorderRadius = 12;
            this.txtDriversalary.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtDriversalary.DefaultText = "";
            this.txtDriversalary.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtDriversalary.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtDriversalary.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtDriversalary.DisabledState.Parent = this.txtDriversalary;
            this.txtDriversalary.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtDriversalary.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.txtDriversalary.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtDriversalary.FocusedState.Parent = this.txtDriversalary;
            this.txtDriversalary.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDriversalary.ForeColor = System.Drawing.Color.White;
            this.txtDriversalary.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtDriversalary.HoverState.Parent = this.txtDriversalary;
            this.txtDriversalary.Location = new System.Drawing.Point(191, 327);
            this.txtDriversalary.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtDriversalary.Name = "txtDriversalary";
            this.txtDriversalary.PasswordChar = '\0';
            this.txtDriversalary.PlaceholderText = "";
            this.txtDriversalary.SelectedText = "";
            this.txtDriversalary.ShadowDecoration.Parent = this.txtDriversalary;
            this.txtDriversalary.Size = new System.Drawing.Size(229, 44);
            this.txtDriversalary.TabIndex = 61;
            // 
            // txtDBno
            // 
            this.txtDBno.BorderRadius = 12;
            this.txtDBno.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtDBno.DefaultText = "";
            this.txtDBno.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtDBno.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtDBno.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtDBno.DisabledState.Parent = this.txtDBno;
            this.txtDBno.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtDBno.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.txtDBno.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtDBno.FocusedState.Parent = this.txtDBno;
            this.txtDBno.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDBno.ForeColor = System.Drawing.Color.White;
            this.txtDBno.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtDBno.HoverState.Parent = this.txtDBno;
            this.txtDBno.Location = new System.Drawing.Point(191, 379);
            this.txtDBno.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtDBno.Name = "txtDBno";
            this.txtDBno.PasswordChar = '\0';
            this.txtDBno.PlaceholderText = "";
            this.txtDBno.SelectedText = "";
            this.txtDBno.ShadowDecoration.Parent = this.txtDBno;
            this.txtDBno.Size = new System.Drawing.Size(229, 44);
            this.txtDBno.TabIndex = 62;
            // 
            // txtAge
            // 
            this.txtAge.BorderRadius = 12;
            this.txtAge.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtAge.DefaultText = "";
            this.txtAge.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtAge.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtAge.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtAge.DisabledState.Parent = this.txtAge;
            this.txtAge.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtAge.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.txtAge.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtAge.FocusedState.Parent = this.txtAge;
            this.txtAge.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAge.ForeColor = System.Drawing.Color.White;
            this.txtAge.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtAge.HoverState.Parent = this.txtAge;
            this.txtAge.Location = new System.Drawing.Point(191, 431);
            this.txtAge.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtAge.Name = "txtAge";
            this.txtAge.PasswordChar = '\0';
            this.txtAge.PlaceholderText = "";
            this.txtAge.SelectedText = "";
            this.txtAge.ShadowDecoration.Parent = this.txtAge;
            this.txtAge.Size = new System.Drawing.Size(229, 44);
            this.txtAge.TabIndex = 63;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Poppins", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(475, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(280, 56);
            this.label1.TabIndex = 0;
            this.label1.Text = "D r i v e r  F o r m";
            // 
            // txtDriverID
            // 
            this.txtDriverID.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.txtDriverID.Controls.Add(this.label1);
            this.txtDriverID.Location = new System.Drawing.Point(0, 1);
            this.txtDriverID.Name = "txtDriverID";
            this.txtDriverID.Size = new System.Drawing.Size(1370, 64);
            this.txtDriverID.TabIndex = 68;
            // 
            // guna2Button6
            // 
            this.guna2Button6.BorderRadius = 12;
            this.guna2Button6.CheckedState.Parent = this.guna2Button6;
            this.guna2Button6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2Button6.CustomImages.Parent = this.guna2Button6;
            this.guna2Button6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.guna2Button6.Font = new System.Drawing.Font("Poppins Black", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button6.ForeColor = System.Drawing.Color.White;
            this.guna2Button6.HoverState.BorderColor = System.Drawing.Color.Lime;
            this.guna2Button6.HoverState.CustomBorderColor = System.Drawing.Color.Lime;
            this.guna2Button6.HoverState.FillColor = System.Drawing.Color.Red;
            this.guna2Button6.HoverState.Parent = this.guna2Button6;
            this.guna2Button6.Location = new System.Drawing.Point(469, 426);
            this.guna2Button6.Name = "guna2Button6";
            this.guna2Button6.ShadowDecoration.Parent = this.guna2Button6;
            this.guna2Button6.Size = new System.Drawing.Size(135, 50);
            this.guna2Button6.TabIndex = 76;
            this.guna2Button6.Text = "C l e a r";
            this.guna2Button6.Click += new System.EventHandler(this.Guna2Button6_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Poppins", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(468, 221);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(0, 34);
            this.label11.TabIndex = 74;
            // 
            // guna2Button1
            // 
            this.guna2Button1.BorderRadius = 12;
            this.guna2Button1.CheckedState.Parent = this.guna2Button1;
            this.guna2Button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2Button1.CustomImages.Parent = this.guna2Button1;
            this.guna2Button1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.guna2Button1.Font = new System.Drawing.Font("Poppins Black", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button1.ForeColor = System.Drawing.Color.White;
            this.guna2Button1.HoverState.BorderColor = System.Drawing.Color.Lime;
            this.guna2Button1.HoverState.CustomBorderColor = System.Drawing.Color.Lime;
            this.guna2Button1.HoverState.FillColor = System.Drawing.Color.Tomato;
            this.guna2Button1.HoverState.Parent = this.guna2Button1;
            this.guna2Button1.Location = new System.Drawing.Point(469, 258);
            this.guna2Button1.Name = "guna2Button1";
            this.guna2Button1.ShadowDecoration.Parent = this.guna2Button1;
            this.guna2Button1.Size = new System.Drawing.Size(135, 50);
            this.guna2Button1.TabIndex = 69;
            this.guna2Button1.Text = "s a v e";
            this.guna2Button1.Click += new System.EventHandler(this.Guna2Button1_Click);
            // 
            // guna2Button2
            // 
            this.guna2Button2.BorderRadius = 12;
            this.guna2Button2.CheckedState.Parent = this.guna2Button2;
            this.guna2Button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2Button2.CustomImages.Parent = this.guna2Button2;
            this.guna2Button2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.guna2Button2.Font = new System.Drawing.Font("Poppins Black", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button2.ForeColor = System.Drawing.Color.White;
            this.guna2Button2.HoverState.BorderColor = System.Drawing.Color.Lime;
            this.guna2Button2.HoverState.CustomBorderColor = System.Drawing.Color.Lime;
            this.guna2Button2.HoverState.FillColor = System.Drawing.Color.Tomato;
            this.guna2Button2.HoverState.Parent = this.guna2Button2;
            this.guna2Button2.Location = new System.Drawing.Point(469, 314);
            this.guna2Button2.Name = "guna2Button2";
            this.guna2Button2.ShadowDecoration.Parent = this.guna2Button2;
            this.guna2Button2.Size = new System.Drawing.Size(135, 50);
            this.guna2Button2.TabIndex = 70;
            this.guna2Button2.Text = "U p d a t e";
            this.guna2Button2.Click += new System.EventHandler(this.Guna2Button2_Click);
            // 
            // guna2Button4
            // 
            this.guna2Button4.BorderRadius = 12;
            this.guna2Button4.CheckedState.Parent = this.guna2Button4;
            this.guna2Button4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2Button4.CustomImages.Parent = this.guna2Button4;
            this.guna2Button4.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.guna2Button4.Font = new System.Drawing.Font("Poppins Black", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button4.ForeColor = System.Drawing.Color.White;
            this.guna2Button4.HoverState.BorderColor = System.Drawing.Color.Lime;
            this.guna2Button4.HoverState.CustomBorderColor = System.Drawing.Color.Lime;
            this.guna2Button4.HoverState.FillColor = System.Drawing.Color.Tomato;
            this.guna2Button4.HoverState.Parent = this.guna2Button4;
            this.guna2Button4.Location = new System.Drawing.Point(469, 370);
            this.guna2Button4.Name = "guna2Button4";
            this.guna2Button4.ShadowDecoration.Parent = this.guna2Button4;
            this.guna2Button4.Size = new System.Drawing.Size(135, 50);
            this.guna2Button4.TabIndex = 71;
            this.guna2Button4.Text = "D e l e t e";
            this.guna2Button4.Click += new System.EventHandler(this.Guna2Button4_Click);
            // 
            // guna2Button3
            // 
            this.guna2Button3.BorderRadius = 12;
            this.guna2Button3.CheckedState.Parent = this.guna2Button3;
            this.guna2Button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2Button3.CustomImages.Parent = this.guna2Button3;
            this.guna2Button3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.guna2Button3.Font = new System.Drawing.Font("Poppins Black", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button3.ForeColor = System.Drawing.Color.White;
            this.guna2Button3.HoverState.BorderColor = System.Drawing.Color.Lime;
            this.guna2Button3.HoverState.CustomBorderColor = System.Drawing.Color.LightGreen;
            this.guna2Button3.HoverState.FillColor = System.Drawing.Color.Lime;
            this.guna2Button3.HoverState.Parent = this.guna2Button3;
            this.guna2Button3.Location = new System.Drawing.Point(1161, 94);
            this.guna2Button3.Name = "guna2Button3";
            this.guna2Button3.ShadowDecoration.Parent = this.guna2Button3;
            this.guna2Button3.Size = new System.Drawing.Size(135, 50);
            this.guna2Button3.TabIndex = 72;
            this.guna2Button3.Text = "Main page";
            this.guna2Button3.Click += new System.EventHandler(this.Guna2Button3_Click);
            // 
            // txtPsid
            // 
            this.txtPsid.BorderRadius = 12;
            this.txtPsid.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtPsid.DefaultText = "";
            this.txtPsid.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtPsid.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtPsid.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtPsid.DisabledState.Parent = this.txtPsid;
            this.txtPsid.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtPsid.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.txtPsid.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtPsid.FocusedState.Parent = this.txtPsid;
            this.txtPsid.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPsid.ForeColor = System.Drawing.Color.White;
            this.txtPsid.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtPsid.HoverState.Parent = this.txtPsid;
            this.txtPsid.Location = new System.Drawing.Point(650, 97);
            this.txtPsid.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtPsid.Name = "txtPsid";
            this.txtPsid.PasswordChar = '\0';
            this.txtPsid.PlaceholderText = "";
            this.txtPsid.SelectedText = "";
            this.txtPsid.ShadowDecoration.Parent = this.txtPsid;
            this.txtPsid.Size = new System.Drawing.Size(424, 44);
            this.txtPsid.TabIndex = 73;
            this.txtPsid.TextChanged += new System.EventHandler(this.TxtPsid_TextChanged);
            // 
            // guna2Button5
            // 
            this.guna2Button5.BorderRadius = 12;
            this.guna2Button5.CheckedState.Parent = this.guna2Button5;
            this.guna2Button5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2Button5.CustomImages.Parent = this.guna2Button5;
            this.guna2Button5.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.guna2Button5.Font = new System.Drawing.Font("Poppins Black", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button5.ForeColor = System.Drawing.Color.White;
            this.guna2Button5.HoverState.BorderColor = System.Drawing.Color.Lime;
            this.guna2Button5.HoverState.CustomBorderColor = System.Drawing.Color.Lime;
            this.guna2Button5.HoverState.FillColor = System.Drawing.Color.Tomato;
            this.guna2Button5.HoverState.Parent = this.guna2Button5;
            this.guna2Button5.Location = new System.Drawing.Point(474, 94);
            this.guna2Button5.Name = "guna2Button5";
            this.guna2Button5.ShadowDecoration.Parent = this.guna2Button5;
            this.guna2Button5.Size = new System.Drawing.Size(135, 50);
            this.guna2Button5.TabIndex = 75;
            this.guna2Button5.Text = "s e a r c h";
            this.guna2Button5.Click += new System.EventHandler(this.Guna2Button5_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.driverIDDataGridViewTextBoxColumn,
            this.drivernameDataGridViewTextBoxColumn,
            this.driverLicienDataGridViewTextBoxColumn,
            this.driversalaryDataGridViewTextBoxColumn,
            this.driverBusnoDataGridViewTextBoxColumn,
            this.ageDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.driverBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(650, 191);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(646, 401);
            this.dataGridView1.TabIndex = 77;
            // 
            // driverIDDataGridViewTextBoxColumn
            // 
            this.driverIDDataGridViewTextBoxColumn.DataPropertyName = "DriverID";
            this.driverIDDataGridViewTextBoxColumn.HeaderText = "DriverID";
            this.driverIDDataGridViewTextBoxColumn.Name = "driverIDDataGridViewTextBoxColumn";
            // 
            // drivernameDataGridViewTextBoxColumn
            // 
            this.drivernameDataGridViewTextBoxColumn.DataPropertyName = "Drivername";
            this.drivernameDataGridViewTextBoxColumn.HeaderText = "Drivername";
            this.drivernameDataGridViewTextBoxColumn.Name = "drivernameDataGridViewTextBoxColumn";
            // 
            // driverLicienDataGridViewTextBoxColumn
            // 
            this.driverLicienDataGridViewTextBoxColumn.DataPropertyName = "DriverLicien";
            this.driverLicienDataGridViewTextBoxColumn.HeaderText = "DriverLicien";
            this.driverLicienDataGridViewTextBoxColumn.Name = "driverLicienDataGridViewTextBoxColumn";
            // 
            // driversalaryDataGridViewTextBoxColumn
            // 
            this.driversalaryDataGridViewTextBoxColumn.DataPropertyName = "Driversalary";
            this.driversalaryDataGridViewTextBoxColumn.HeaderText = "Driversalary";
            this.driversalaryDataGridViewTextBoxColumn.Name = "driversalaryDataGridViewTextBoxColumn";
            // 
            // driverBusnoDataGridViewTextBoxColumn
            // 
            this.driverBusnoDataGridViewTextBoxColumn.DataPropertyName = "DriverBusno";
            this.driverBusnoDataGridViewTextBoxColumn.HeaderText = "DriverBusno";
            this.driverBusnoDataGridViewTextBoxColumn.Name = "driverBusnoDataGridViewTextBoxColumn";
            // 
            // ageDataGridViewTextBoxColumn
            // 
            this.ageDataGridViewTextBoxColumn.DataPropertyName = "Age";
            this.ageDataGridViewTextBoxColumn.HeaderText = "Age";
            this.ageDataGridViewTextBoxColumn.Name = "ageDataGridViewTextBoxColumn";
            // 
            // driverBindingSource
            // 
            this.driverBindingSource.DataMember = "Driver";
            this.driverBindingSource.DataSource = this.sahalTLDBDataSet2;
            // 
            // sahalTLDBDataSet2
            // 
            this.sahalTLDBDataSet2.DataSetName = "SahalTLDBDataSet2";
            this.sahalTLDBDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // driverTableAdapter
            // 
            this.driverTableAdapter.ClearBeforeFill = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::SahlaTranportLogistics.Properties.Resources.Mask_Group_9;
            this.pictureBox1.Location = new System.Drawing.Point(0, 452);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(349, 262);
            this.pictureBox1.TabIndex = 78;
            this.pictureBox1.TabStop = false;
            // 
            // Driver
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1370, 707);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.guna2Button5);
            this.Controls.Add(this.txtPsid);
            this.Controls.Add(this.guna2Button3);
            this.Controls.Add(this.guna2Button4);
            this.Controls.Add(this.guna2Button2);
            this.Controls.Add(this.guna2Button1);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.guna2Button6);
            this.Controls.Add(this.txtDriverID);
            this.Controls.Add(this.txtAge);
            this.Controls.Add(this.txtDBno);
            this.Controls.Add(this.txtDriversalary);
            this.Controls.Add(this.txtDriverLicien);
            this.Controls.Add(this.txtDrivername);
            this.Controls.Add(this.txtDriverID1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Driver";
            this.Text = "Driver";
            this.Load += new System.EventHandler(this.Driver_Load);
            this.txtDriverID.ResumeLayout(false);
            this.txtDriverID.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.driverBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sahalTLDBDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridViewTextBoxColumn serialnoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sandernameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sandernumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn recievernumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gongToDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn formtoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn quantityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pirceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn recievernameDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private Guna.UI2.WinForms.Guna2TextBox txtDriverID1;
        private Guna.UI2.WinForms.Guna2TextBox txtDrivername;
        private Guna.UI2.WinForms.Guna2TextBox txtDriverLicien;
        private Guna.UI2.WinForms.Guna2TextBox txtDriversalary;
        private Guna.UI2.WinForms.Guna2TextBox txtDBno;
        private Guna.UI2.WinForms.Guna2TextBox txtAge;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel txtDriverID;
        private Guna.UI2.WinForms.Guna2Button guna2Button6;
        private System.Windows.Forms.Label label11;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private Guna.UI2.WinForms.Guna2Button guna2Button2;
        private Guna.UI2.WinForms.Guna2Button guna2Button4;
        private Guna.UI2.WinForms.Guna2Button guna2Button3;
        private Guna.UI2.WinForms.Guna2TextBox txtPsid;
        private Guna.UI2.WinForms.Guna2Button guna2Button5;
        private System.Windows.Forms.DataGridView dataGridView1;
        private SahalTLDBDataSet2 sahalTLDBDataSet2;
        private System.Windows.Forms.BindingSource driverBindingSource;
        private SahalTLDBDataSet2TableAdapters.DriverTableAdapter driverTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn driverIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn drivernameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn driverLicienDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn driversalaryDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn driverBusnoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ageDataGridViewTextBoxColumn;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}