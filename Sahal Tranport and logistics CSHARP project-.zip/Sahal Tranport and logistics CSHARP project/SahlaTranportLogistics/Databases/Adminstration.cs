﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SahlaTranportLogistics
{
    public partial class Adminstration : Form
    {
        public Adminstration()
        {
            InitializeComponent();
        }

        private void Guna2Button1_Click(object sender, EventArgs e)
        {
            SingUp fr = new SingUp();
            fr.Show();
            this.Close();

        }

        private void Guna2Button2_Click(object sender, EventArgs e)
        {
            Login fr = new Login();
            fr.Show();
            this.Close();

        }

        private void Guna2Button3_Click(object sender, EventArgs e)
        {
            forgetpass fr = new forgetpass();
            fr.Show();
            this.Close();

        }

        private void Guna2Button4_Click(object sender, EventArgs e)
        {
            this.Close();


        }

        private void Guna2Button5_Click(object sender, EventArgs e)
        {
            MainPage fr = new MainPage();
            fr.Show();
            this.Close();
        }
    }
}
