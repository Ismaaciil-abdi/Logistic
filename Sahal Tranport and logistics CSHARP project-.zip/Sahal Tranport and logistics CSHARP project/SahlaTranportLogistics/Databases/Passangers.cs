﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SahlaTranportLogistics
{
    public partial class Passangers : Form
    {
        public Passangers()
        {
            InitializeComponent();
        }


        private void DisplayData()
        {
            SqlConnection con = new SqlConnection(@"Data Source=HP\ISMAIL;Initial Catalog=SahalTLDB;Integrated Security=True");
            SqlDataAdapter adapt;
            con.Open();
            DataTable dt = new DataTable();
            adapt = new SqlDataAdapter("select * from Passanger", con);
            adapt.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }


        private void Passangers_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'sahalTLDBDataSet.Passanger' table. You can move, or remove it, as needed.
            this.passangerTableAdapter.Fill(this.sahalTLDBDataSet.Passanger);

        }

        private void Label3_Click(object sender, EventArgs e)
        {

        }

        private void Guna2TextBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void Label6_Click(object sender, EventArgs e)
        {

        }

        private void Label9_Click(object sender, EventArgs e)
        {

        }

        private void Label10_Click(object sender, EventArgs e)
        {

        }

        private void Guna2Button2_Click(object sender, EventArgs e)
        {

            SqlConnection con = new SqlConnection(@"Data Source=HP\ISMAIL;Initial Catalog=SahalTLDB;Integrated Security=True");
            SqlCommand cmd;
            if (txtPassID.Text != "" && txtPassname.Text != "" && txtnumber.Text != "" && txtto.Text != "" && txtfrom.Text != "" && txtprice.Text != "" && txtbusno.Text != "" && txtsiteno.Text != "" && txttimeout.Text != "")
            {
                cmd = new SqlCommand("update Passanger set PassID=@PassID, PassName=@PassName,  Number=@Number, gointo=@gointo, formto=@formto, price=@price, Busno=@Busno,Siteno=@Siteno, timeout=@timeout  where PassID=@PassID", con);
                con.Open();

                cmd.Parameters.AddWithValue("@PassID", txtPassID.Text);
                cmd.Parameters.AddWithValue("@PassName", txtPassname.Text);
                cmd.Parameters.AddWithValue("@Number", txtnumber.Text);
                cmd.Parameters.AddWithValue("@gointo", txtto.Text);
                cmd.Parameters.AddWithValue("@formto", txtfrom.Text);
                cmd.Parameters.AddWithValue("@price", txtprice.Text);
                cmd.Parameters.AddWithValue("@Busno", txtbusno.Text);
                cmd.Parameters.AddWithValue("@Siteno", txtsiteno.Text);
                cmd.Parameters.AddWithValue("@timeout", txttimeout.Text);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Record Updated Successfully");
                con.Close();
            }
            else
            {
                MessageBox.Show("Please Select Record to Update");
            }
            DisplayData();
        }

        private void Guna2Button4_Click(object sender, EventArgs e)
        {


            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=HP\ISMAIL;Initial Catalog=SahalTLDB;Integrated Security=True");
                con.Open();

                string str = "DELETE FROM Passanger WHERE PassID = '" + txtPsid.Text + "'";

                SqlCommand cmd = new SqlCommand(str, con);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Record Delete Successfully");

                using (SqlConnection newcon = new SqlConnection(@"Data Source=HP\ISMAIL;Initial Catalog=SahalTLDB;Integrated Security=True"))
                {
                    string str1 = @"SELECT * from Passanger";
                    SqlCommand cmd1 = new SqlCommand(str1, newcon);
                    SqlDataAdapter da = new SqlDataAdapter(cmd1);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dataGridView1.DataSource = new BindingSource(dt, null);

                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                MessageBox.Show("Please Enter Passanger Id");
            }
            DisplayData();



        }

        private void Guna2Button3_Click(object sender, EventArgs e)
        {
            MainPage mr = new MainPage();
            mr.Show();
            this.Close();
        }

        private void Guna2Button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=HP\ISMAIL;Initial Catalog=SahalTLDB;Integrated Security=True");
            con.Open();
            try
            {
                string str = " INSERT INTO Passanger(PassID,PassName,Number,gointo,formto,price,Busno,Siteno,timeout) VALUES('" + txtPassID.Text + "','" + txtPassname.Text + "' ,'" + txtnumber.Text + "' ,'" + txtto.Text + "' ,'" + txtfrom.Text + "','" + txtprice.Text + "','" + txtbusno.Text + "','" + txtsiteno.Text + "','" + txttimeout.Text + "'); ";
                SqlCommand cmd = new SqlCommand(str, con);
                cmd.ExecuteNonQuery();
                string str1 = "select max(PassID) from Passanger ;";
                SqlCommand cmd1 = new SqlCommand(str1, con);
                SqlDataReader dr = cmd1.ExecuteReader();
                if (dr.Read())
                {
                    MessageBox.Show("Successfully Saved. ");
                }
            }
            catch (SqlException excep)
            {
                MessageBox.Show(excep.Message);
            }
            con.Close();

            DisplayData();
        }

        private void Guna2TextBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void Guna2Button5_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=HP\ISMAIL;Initial Catalog=SahalTLDB;Integrated Security=True");
                {
                    string str1 = @"SELECT * from Passanger where PassID = '" + txtPsid.Text + "'";
                    SqlCommand cmd1 = new SqlCommand(str1, con);
                    SqlDataAdapter da = new SqlDataAdapter(cmd1);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dataGridView1.DataSource = new BindingSource(dt, null);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                MessageBox.Show("Please Enter Passanger ID");
            }
        }

        private void Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void Txttimeout_TextChanged(object sender, EventArgs e)
        {

        }

        private void Txtsiteno_TextChanged(object sender, EventArgs e)
        {

        }

        private void Txtbusno_TextChanged(object sender, EventArgs e)
        {

        }

        private void Txtprice_TextChanged(object sender, EventArgs e)
        {

        }

        private void Txtnumber_TextChanged(object sender, EventArgs e)
        {

        }

        private void TxtPassname_TextChanged(object sender, EventArgs e)
        {

        }

        private void TxtPassID_TextChanged(object sender, EventArgs e)
        {

        }

        private void Label2_Click(object sender, EventArgs e)
        {

        }

        private void Label4_Click(object sender, EventArgs e)
        {

        }

        private void Label5_Click(object sender, EventArgs e)
        {

        }

        private void Label7_Click(object sender, EventArgs e)
        {

        }

        private void Label9_Click_1(object sender, EventArgs e)
        {

        }

        private void Label8_Click(object sender, EventArgs e)
        {

        }

        private void Guna2Button6_Click(object sender, EventArgs e)
        {
            txtPassID.Text = "";
            txtbusno.Text = "";
            txtfrom.Text = "";
            txtPassname.Text = "";
            txtprice.Text = "";
            txttimeout.Text = "";
            txtto.Text = "";
            txtprice.Text = "";
            txtnumber.Text = "";
            txtsiteno.Text = "";
        }

        private void DataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
