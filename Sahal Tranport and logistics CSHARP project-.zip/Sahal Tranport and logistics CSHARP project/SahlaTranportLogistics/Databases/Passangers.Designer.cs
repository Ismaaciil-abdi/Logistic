﻿namespace SahlaTranportLogistics
{
    partial class Passangers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txtPassID = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtPassname = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtnumber = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtto = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtfrom = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtprice = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtbusno = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtsiteno = new Guna.UI2.WinForms.Guna2TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txttimeout = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button2 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button3 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button4 = new Guna.UI2.WinForms.Guna2Button();
            this.txtPsid = new Guna.UI2.WinForms.Guna2TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.guna2Button5 = new Guna.UI2.WinForms.Guna2Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.passIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.passNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.numberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gointoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.formtoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.priceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.busnoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sitenoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.timeoutDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.passangerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sahalTLDBDataSet = new SahlaTranportLogistics.SahalTLDBDataSet();
            this.passangerTableAdapter = new SahlaTranportLogistics.SahalTLDBDataSetTableAdapters.PassangerTableAdapter();
            this.guna2Button6 = new Guna.UI2.WinForms.Guna2Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.passangerBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sahalTLDBDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(-1, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1371, 62);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.Panel1_Paint);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Poppins", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(473, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(314, 56);
            this.label1.TabIndex = 0;
            this.label1.Text = "Passangers  form";
            this.label1.Click += new System.EventHandler(this.Label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Poppins", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(12, 85);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(145, 34);
            this.label2.TabIndex = 1;
            this.label2.Text = "Passanger ID";
            this.label2.Click += new System.EventHandler(this.Label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Poppins", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(12, 138);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(183, 34);
            this.label3.TabIndex = 2;
            this.label3.Text = "Passanger name";
            this.label3.Click += new System.EventHandler(this.Label3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Poppins", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(12, 192);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(95, 34);
            this.label4.TabIndex = 3;
            this.label4.Text = "Number";
            this.label4.Click += new System.EventHandler(this.Label4_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Poppins", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(12, 244);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 34);
            this.label5.TabIndex = 4;
            this.label5.Text = "TO";
            this.label5.Click += new System.EventHandler(this.Label5_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Poppins", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(12, 296);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(65, 34);
            this.label6.TabIndex = 5;
            this.label6.Text = "From";
            this.label6.Click += new System.EventHandler(this.Label6_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Poppins", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(12, 348);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(64, 34);
            this.label7.TabIndex = 6;
            this.label7.Text = "Price";
            this.label7.Click += new System.EventHandler(this.Label7_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Poppins", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(12, 400);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(81, 34);
            this.label8.TabIndex = 7;
            this.label8.Text = "Bus no";
            this.label8.Click += new System.EventHandler(this.Label8_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Poppins", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(12, 504);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(101, 34);
            this.label10.TabIndex = 9;
            this.label10.Text = "Time out";
            this.label10.Click += new System.EventHandler(this.Label10_Click);
            // 
            // txtPassID
            // 
            this.txtPassID.BorderRadius = 12;
            this.txtPassID.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtPassID.DefaultText = "";
            this.txtPassID.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtPassID.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtPassID.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtPassID.DisabledState.Parent = this.txtPassID;
            this.txtPassID.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtPassID.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.txtPassID.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtPassID.FocusedState.Parent = this.txtPassID;
            this.txtPassID.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPassID.ForeColor = System.Drawing.Color.White;
            this.txtPassID.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtPassID.HoverState.Parent = this.txtPassID;
            this.txtPassID.Location = new System.Drawing.Point(194, 80);
            this.txtPassID.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtPassID.Name = "txtPassID";
            this.txtPassID.PasswordChar = '\0';
            this.txtPassID.PlaceholderText = "";
            this.txtPassID.SelectedText = "";
            this.txtPassID.ShadowDecoration.Parent = this.txtPassID;
            this.txtPassID.Size = new System.Drawing.Size(229, 44);
            this.txtPassID.TabIndex = 10;
            this.txtPassID.TextChanged += new System.EventHandler(this.TxtPassID_TextChanged);
            // 
            // txtPassname
            // 
            this.txtPassname.BorderRadius = 12;
            this.txtPassname.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtPassname.DefaultText = "";
            this.txtPassname.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtPassname.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtPassname.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtPassname.DisabledState.Parent = this.txtPassname;
            this.txtPassname.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtPassname.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.txtPassname.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtPassname.FocusedState.Parent = this.txtPassname;
            this.txtPassname.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPassname.ForeColor = System.Drawing.Color.White;
            this.txtPassname.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtPassname.HoverState.Parent = this.txtPassname;
            this.txtPassname.Location = new System.Drawing.Point(194, 133);
            this.txtPassname.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtPassname.Name = "txtPassname";
            this.txtPassname.PasswordChar = '\0';
            this.txtPassname.PlaceholderText = "";
            this.txtPassname.SelectedText = "";
            this.txtPassname.ShadowDecoration.Parent = this.txtPassname;
            this.txtPassname.Size = new System.Drawing.Size(229, 44);
            this.txtPassname.TabIndex = 11;
            this.txtPassname.TextChanged += new System.EventHandler(this.TxtPassname_TextChanged);
            // 
            // txtnumber
            // 
            this.txtnumber.BorderRadius = 12;
            this.txtnumber.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtnumber.DefaultText = "";
            this.txtnumber.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtnumber.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtnumber.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtnumber.DisabledState.Parent = this.txtnumber;
            this.txtnumber.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtnumber.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.txtnumber.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtnumber.FocusedState.Parent = this.txtnumber;
            this.txtnumber.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnumber.ForeColor = System.Drawing.Color.White;
            this.txtnumber.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtnumber.HoverState.Parent = this.txtnumber;
            this.txtnumber.Location = new System.Drawing.Point(194, 187);
            this.txtnumber.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtnumber.Name = "txtnumber";
            this.txtnumber.PasswordChar = '\0';
            this.txtnumber.PlaceholderText = "";
            this.txtnumber.SelectedText = "";
            this.txtnumber.ShadowDecoration.Parent = this.txtnumber;
            this.txtnumber.Size = new System.Drawing.Size(229, 44);
            this.txtnumber.TabIndex = 12;
            this.txtnumber.TextChanged += new System.EventHandler(this.Txtnumber_TextChanged);
            // 
            // txtto
            // 
            this.txtto.BorderRadius = 12;
            this.txtto.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtto.DefaultText = "";
            this.txtto.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtto.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtto.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtto.DisabledState.Parent = this.txtto;
            this.txtto.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtto.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.txtto.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtto.FocusedState.Parent = this.txtto;
            this.txtto.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtto.ForeColor = System.Drawing.Color.White;
            this.txtto.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtto.HoverState.Parent = this.txtto;
            this.txtto.Location = new System.Drawing.Point(194, 239);
            this.txtto.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtto.Name = "txtto";
            this.txtto.PasswordChar = '\0';
            this.txtto.PlaceholderText = "";
            this.txtto.SelectedText = "";
            this.txtto.ShadowDecoration.Parent = this.txtto;
            this.txtto.Size = new System.Drawing.Size(229, 44);
            this.txtto.TabIndex = 13;
            this.txtto.TextChanged += new System.EventHandler(this.Guna2TextBox4_TextChanged);
            // 
            // txtfrom
            // 
            this.txtfrom.BorderRadius = 12;
            this.txtfrom.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtfrom.DefaultText = "";
            this.txtfrom.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtfrom.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtfrom.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtfrom.DisabledState.Parent = this.txtfrom;
            this.txtfrom.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtfrom.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.txtfrom.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtfrom.FocusedState.Parent = this.txtfrom;
            this.txtfrom.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtfrom.ForeColor = System.Drawing.Color.White;
            this.txtfrom.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtfrom.HoverState.Parent = this.txtfrom;
            this.txtfrom.Location = new System.Drawing.Point(194, 291);
            this.txtfrom.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtfrom.Name = "txtfrom";
            this.txtfrom.PasswordChar = '\0';
            this.txtfrom.PlaceholderText = "";
            this.txtfrom.SelectedText = "";
            this.txtfrom.ShadowDecoration.Parent = this.txtfrom;
            this.txtfrom.Size = new System.Drawing.Size(229, 44);
            this.txtfrom.TabIndex = 14;
            this.txtfrom.TextChanged += new System.EventHandler(this.Guna2TextBox5_TextChanged);
            // 
            // txtprice
            // 
            this.txtprice.BorderRadius = 12;
            this.txtprice.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtprice.DefaultText = "";
            this.txtprice.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtprice.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtprice.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtprice.DisabledState.Parent = this.txtprice;
            this.txtprice.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtprice.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.txtprice.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtprice.FocusedState.Parent = this.txtprice;
            this.txtprice.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtprice.ForeColor = System.Drawing.Color.White;
            this.txtprice.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtprice.HoverState.Parent = this.txtprice;
            this.txtprice.Location = new System.Drawing.Point(194, 343);
            this.txtprice.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtprice.Name = "txtprice";
            this.txtprice.PasswordChar = '\0';
            this.txtprice.PlaceholderText = "";
            this.txtprice.SelectedText = "";
            this.txtprice.ShadowDecoration.Parent = this.txtprice;
            this.txtprice.Size = new System.Drawing.Size(229, 44);
            this.txtprice.TabIndex = 15;
            this.txtprice.TextChanged += new System.EventHandler(this.Txtprice_TextChanged);
            // 
            // txtbusno
            // 
            this.txtbusno.BorderRadius = 12;
            this.txtbusno.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtbusno.DefaultText = "";
            this.txtbusno.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtbusno.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtbusno.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtbusno.DisabledState.Parent = this.txtbusno;
            this.txtbusno.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtbusno.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.txtbusno.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtbusno.FocusedState.Parent = this.txtbusno;
            this.txtbusno.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbusno.ForeColor = System.Drawing.Color.White;
            this.txtbusno.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtbusno.HoverState.Parent = this.txtbusno;
            this.txtbusno.Location = new System.Drawing.Point(194, 395);
            this.txtbusno.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtbusno.Name = "txtbusno";
            this.txtbusno.PasswordChar = '\0';
            this.txtbusno.PlaceholderText = "";
            this.txtbusno.SelectedText = "";
            this.txtbusno.ShadowDecoration.Parent = this.txtbusno;
            this.txtbusno.Size = new System.Drawing.Size(229, 44);
            this.txtbusno.TabIndex = 16;
            this.txtbusno.TextChanged += new System.EventHandler(this.Txtbusno_TextChanged);
            // 
            // txtsiteno
            // 
            this.txtsiteno.BorderRadius = 12;
            this.txtsiteno.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtsiteno.DefaultText = "";
            this.txtsiteno.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtsiteno.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtsiteno.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtsiteno.DisabledState.Parent = this.txtsiteno;
            this.txtsiteno.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtsiteno.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.txtsiteno.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtsiteno.FocusedState.Parent = this.txtsiteno;
            this.txtsiteno.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsiteno.ForeColor = System.Drawing.Color.White;
            this.txtsiteno.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtsiteno.HoverState.Parent = this.txtsiteno;
            this.txtsiteno.Location = new System.Drawing.Point(194, 447);
            this.txtsiteno.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtsiteno.Name = "txtsiteno";
            this.txtsiteno.PasswordChar = '\0';
            this.txtsiteno.PlaceholderText = "";
            this.txtsiteno.SelectedText = "";
            this.txtsiteno.ShadowDecoration.Parent = this.txtsiteno;
            this.txtsiteno.Size = new System.Drawing.Size(229, 44);
            this.txtsiteno.TabIndex = 19;
            this.txtsiteno.TextChanged += new System.EventHandler(this.Txtsiteno_TextChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Poppins", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(12, 452);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(82, 34);
            this.label9.TabIndex = 18;
            this.label9.Text = "Site no";
            this.label9.Click += new System.EventHandler(this.Label9_Click_1);
            // 
            // txttimeout
            // 
            this.txttimeout.BorderRadius = 12;
            this.txttimeout.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txttimeout.DefaultText = "";
            this.txttimeout.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txttimeout.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txttimeout.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txttimeout.DisabledState.Parent = this.txttimeout;
            this.txttimeout.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txttimeout.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.txttimeout.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txttimeout.FocusedState.Parent = this.txttimeout;
            this.txttimeout.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txttimeout.ForeColor = System.Drawing.Color.White;
            this.txttimeout.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txttimeout.HoverState.Parent = this.txttimeout;
            this.txttimeout.Location = new System.Drawing.Point(194, 499);
            this.txttimeout.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txttimeout.Name = "txttimeout";
            this.txttimeout.PasswordChar = '\0';
            this.txttimeout.PlaceholderText = "";
            this.txttimeout.SelectedText = "";
            this.txttimeout.ShadowDecoration.Parent = this.txttimeout;
            this.txttimeout.Size = new System.Drawing.Size(229, 44);
            this.txttimeout.TabIndex = 21;
            this.txttimeout.TextChanged += new System.EventHandler(this.Txttimeout_TextChanged);
            // 
            // guna2Button1
            // 
            this.guna2Button1.BorderRadius = 12;
            this.guna2Button1.CheckedState.Parent = this.guna2Button1;
            this.guna2Button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2Button1.CustomImages.Parent = this.guna2Button1;
            this.guna2Button1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.guna2Button1.Font = new System.Drawing.Font("Poppins Black", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button1.ForeColor = System.Drawing.Color.White;
            this.guna2Button1.HoverState.BorderColor = System.Drawing.Color.Lime;
            this.guna2Button1.HoverState.CustomBorderColor = System.Drawing.Color.Lime;
            this.guna2Button1.HoverState.FillColor = System.Drawing.Color.Tomato;
            this.guna2Button1.HoverState.Parent = this.guna2Button1;
            this.guna2Button1.Location = new System.Drawing.Point(500, 74);
            this.guna2Button1.Name = "guna2Button1";
            this.guna2Button1.ShadowDecoration.Parent = this.guna2Button1;
            this.guna2Button1.Size = new System.Drawing.Size(135, 50);
            this.guna2Button1.TabIndex = 22;
            this.guna2Button1.Text = "s a v e";
            this.guna2Button1.Click += new System.EventHandler(this.Guna2Button1_Click);
            // 
            // guna2Button2
            // 
            this.guna2Button2.BorderRadius = 12;
            this.guna2Button2.CheckedState.Parent = this.guna2Button2;
            this.guna2Button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2Button2.CustomImages.Parent = this.guna2Button2;
            this.guna2Button2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.guna2Button2.Font = new System.Drawing.Font("Poppins Black", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button2.ForeColor = System.Drawing.Color.White;
            this.guna2Button2.HoverState.BorderColor = System.Drawing.Color.Lime;
            this.guna2Button2.HoverState.CustomBorderColor = System.Drawing.Color.Lime;
            this.guna2Button2.HoverState.FillColor = System.Drawing.Color.Tomato;
            this.guna2Button2.HoverState.Parent = this.guna2Button2;
            this.guna2Button2.Location = new System.Drawing.Point(661, 74);
            this.guna2Button2.Name = "guna2Button2";
            this.guna2Button2.ShadowDecoration.Parent = this.guna2Button2;
            this.guna2Button2.Size = new System.Drawing.Size(135, 50);
            this.guna2Button2.TabIndex = 23;
            this.guna2Button2.Text = "U p d a t e";
            this.guna2Button2.Click += new System.EventHandler(this.Guna2Button2_Click);
            // 
            // guna2Button3
            // 
            this.guna2Button3.BorderRadius = 12;
            this.guna2Button3.CheckedState.Parent = this.guna2Button3;
            this.guna2Button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2Button3.CustomImages.Parent = this.guna2Button3;
            this.guna2Button3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.guna2Button3.Font = new System.Drawing.Font("Poppins Black", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button3.ForeColor = System.Drawing.Color.White;
            this.guna2Button3.HoverState.BorderColor = System.Drawing.Color.Lime;
            this.guna2Button3.HoverState.CustomBorderColor = System.Drawing.Color.LightGreen;
            this.guna2Button3.HoverState.FillColor = System.Drawing.Color.Lime;
            this.guna2Button3.HoverState.Parent = this.guna2Button3;
            this.guna2Button3.Location = new System.Drawing.Point(1192, 74);
            this.guna2Button3.Name = "guna2Button3";
            this.guna2Button3.ShadowDecoration.Parent = this.guna2Button3;
            this.guna2Button3.Size = new System.Drawing.Size(135, 50);
            this.guna2Button3.TabIndex = 25;
            this.guna2Button3.Text = "Main page";
            this.guna2Button3.Click += new System.EventHandler(this.Guna2Button3_Click);
            // 
            // guna2Button4
            // 
            this.guna2Button4.BorderRadius = 12;
            this.guna2Button4.CheckedState.Parent = this.guna2Button4;
            this.guna2Button4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2Button4.CustomImages.Parent = this.guna2Button4;
            this.guna2Button4.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.guna2Button4.Font = new System.Drawing.Font("Poppins Black", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button4.ForeColor = System.Drawing.Color.White;
            this.guna2Button4.HoverState.BorderColor = System.Drawing.Color.Lime;
            this.guna2Button4.HoverState.CustomBorderColor = System.Drawing.Color.Lime;
            this.guna2Button4.HoverState.FillColor = System.Drawing.Color.Tomato;
            this.guna2Button4.HoverState.Parent = this.guna2Button4;
            this.guna2Button4.Location = new System.Drawing.Point(814, 74);
            this.guna2Button4.Name = "guna2Button4";
            this.guna2Button4.ShadowDecoration.Parent = this.guna2Button4;
            this.guna2Button4.Size = new System.Drawing.Size(135, 50);
            this.guna2Button4.TabIndex = 24;
            this.guna2Button4.Text = "D e l e t e";
            this.guna2Button4.Click += new System.EventHandler(this.Guna2Button4_Click);
            // 
            // txtPsid
            // 
            this.txtPsid.BorderRadius = 12;
            this.txtPsid.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtPsid.DefaultText = "";
            this.txtPsid.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtPsid.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtPsid.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtPsid.DisabledState.Parent = this.txtPsid;
            this.txtPsid.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtPsid.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.txtPsid.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtPsid.FocusedState.Parent = this.txtPsid;
            this.txtPsid.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPsid.ForeColor = System.Drawing.Color.White;
            this.txtPsid.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtPsid.HoverState.Parent = this.txtPsid;
            this.txtPsid.Location = new System.Drawing.Point(649, 157);
            this.txtPsid.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtPsid.Name = "txtPsid";
            this.txtPsid.PasswordChar = '\0';
            this.txtPsid.PlaceholderText = "";
            this.txtPsid.SelectedText = "";
            this.txtPsid.ShadowDecoration.Parent = this.txtPsid;
            this.txtPsid.Size = new System.Drawing.Size(482, 44);
            this.txtPsid.TabIndex = 26;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Poppins", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(497, 170);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(0, 34);
            this.label11.TabIndex = 27;
            // 
            // guna2Button5
            // 
            this.guna2Button5.BorderRadius = 12;
            this.guna2Button5.CheckedState.Parent = this.guna2Button5;
            this.guna2Button5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2Button5.CustomImages.Parent = this.guna2Button5;
            this.guna2Button5.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.guna2Button5.Font = new System.Drawing.Font("Poppins Black", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button5.ForeColor = System.Drawing.Color.White;
            this.guna2Button5.HoverState.BorderColor = System.Drawing.Color.Lime;
            this.guna2Button5.HoverState.CustomBorderColor = System.Drawing.Color.Lime;
            this.guna2Button5.HoverState.FillColor = System.Drawing.Color.Tomato;
            this.guna2Button5.HoverState.Parent = this.guna2Button5;
            this.guna2Button5.Location = new System.Drawing.Point(503, 154);
            this.guna2Button5.Name = "guna2Button5";
            this.guna2Button5.ShadowDecoration.Parent = this.guna2Button5;
            this.guna2Button5.Size = new System.Drawing.Size(135, 50);
            this.guna2Button5.TabIndex = 28;
            this.guna2Button5.Text = "s e a r c h";
            this.guna2Button5.Click += new System.EventHandler(this.Guna2Button5_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.passIDDataGridViewTextBoxColumn,
            this.passNameDataGridViewTextBoxColumn,
            this.numberDataGridViewTextBoxColumn,
            this.gointoDataGridViewTextBoxColumn,
            this.formtoDataGridViewTextBoxColumn,
            this.priceDataGridViewTextBoxColumn,
            this.busnoDataGridViewTextBoxColumn,
            this.sitenoDataGridViewTextBoxColumn,
            this.timeoutDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.passangerBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(430, 244);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(940, 348);
            this.dataGridView1.TabIndex = 29;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DataGridView1_CellContentClick);
            // 
            // passIDDataGridViewTextBoxColumn
            // 
            this.passIDDataGridViewTextBoxColumn.DataPropertyName = "PassID";
            this.passIDDataGridViewTextBoxColumn.HeaderText = "PassID";
            this.passIDDataGridViewTextBoxColumn.Name = "passIDDataGridViewTextBoxColumn";
            // 
            // passNameDataGridViewTextBoxColumn
            // 
            this.passNameDataGridViewTextBoxColumn.DataPropertyName = "PassName";
            this.passNameDataGridViewTextBoxColumn.HeaderText = "PassName";
            this.passNameDataGridViewTextBoxColumn.Name = "passNameDataGridViewTextBoxColumn";
            // 
            // numberDataGridViewTextBoxColumn
            // 
            this.numberDataGridViewTextBoxColumn.DataPropertyName = "Number";
            this.numberDataGridViewTextBoxColumn.HeaderText = "Number";
            this.numberDataGridViewTextBoxColumn.Name = "numberDataGridViewTextBoxColumn";
            // 
            // gointoDataGridViewTextBoxColumn
            // 
            this.gointoDataGridViewTextBoxColumn.DataPropertyName = "gointo";
            this.gointoDataGridViewTextBoxColumn.HeaderText = "gointo";
            this.gointoDataGridViewTextBoxColumn.Name = "gointoDataGridViewTextBoxColumn";
            // 
            // formtoDataGridViewTextBoxColumn
            // 
            this.formtoDataGridViewTextBoxColumn.DataPropertyName = "formto";
            this.formtoDataGridViewTextBoxColumn.HeaderText = "formto";
            this.formtoDataGridViewTextBoxColumn.Name = "formtoDataGridViewTextBoxColumn";
            // 
            // priceDataGridViewTextBoxColumn
            // 
            this.priceDataGridViewTextBoxColumn.DataPropertyName = "price";
            this.priceDataGridViewTextBoxColumn.HeaderText = "price";
            this.priceDataGridViewTextBoxColumn.Name = "priceDataGridViewTextBoxColumn";
            // 
            // busnoDataGridViewTextBoxColumn
            // 
            this.busnoDataGridViewTextBoxColumn.DataPropertyName = "Busno";
            this.busnoDataGridViewTextBoxColumn.HeaderText = "Busno";
            this.busnoDataGridViewTextBoxColumn.Name = "busnoDataGridViewTextBoxColumn";
            // 
            // sitenoDataGridViewTextBoxColumn
            // 
            this.sitenoDataGridViewTextBoxColumn.DataPropertyName = "Siteno";
            this.sitenoDataGridViewTextBoxColumn.HeaderText = "Siteno";
            this.sitenoDataGridViewTextBoxColumn.Name = "sitenoDataGridViewTextBoxColumn";
            // 
            // timeoutDataGridViewTextBoxColumn
            // 
            this.timeoutDataGridViewTextBoxColumn.DataPropertyName = "timeout";
            this.timeoutDataGridViewTextBoxColumn.HeaderText = "timeout";
            this.timeoutDataGridViewTextBoxColumn.Name = "timeoutDataGridViewTextBoxColumn";
            // 
            // passangerBindingSource
            // 
            this.passangerBindingSource.DataMember = "Passanger";
            this.passangerBindingSource.DataSource = this.sahalTLDBDataSet;
            // 
            // sahalTLDBDataSet
            // 
            this.sahalTLDBDataSet.DataSetName = "SahalTLDBDataSet";
            this.sahalTLDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // passangerTableAdapter
            // 
            this.passangerTableAdapter.ClearBeforeFill = true;
            // 
            // guna2Button6
            // 
            this.guna2Button6.BorderRadius = 12;
            this.guna2Button6.CheckedState.Parent = this.guna2Button6;
            this.guna2Button6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2Button6.CustomImages.Parent = this.guna2Button6;
            this.guna2Button6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(77)))), ((int)(((byte)(145)))));
            this.guna2Button6.Font = new System.Drawing.Font("Poppins Black", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button6.ForeColor = System.Drawing.Color.White;
            this.guna2Button6.HoverState.BorderColor = System.Drawing.Color.Lime;
            this.guna2Button6.HoverState.CustomBorderColor = System.Drawing.Color.Lime;
            this.guna2Button6.HoverState.FillColor = System.Drawing.Color.Red;
            this.guna2Button6.HoverState.Parent = this.guna2Button6;
            this.guna2Button6.Location = new System.Drawing.Point(973, 74);
            this.guna2Button6.Name = "guna2Button6";
            this.guna2Button6.ShadowDecoration.Parent = this.guna2Button6;
            this.guna2Button6.Size = new System.Drawing.Size(135, 50);
            this.guna2Button6.TabIndex = 30;
            this.guna2Button6.Text = "C l e a r";
            this.guna2Button6.Click += new System.EventHandler(this.Guna2Button6_Click);
            // 
            // Passangers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1370, 604);
            this.Controls.Add(this.guna2Button6);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.guna2Button5);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.txtPsid);
            this.Controls.Add(this.guna2Button3);
            this.Controls.Add(this.guna2Button4);
            this.Controls.Add(this.guna2Button2);
            this.Controls.Add(this.guna2Button1);
            this.Controls.Add(this.txttimeout);
            this.Controls.Add(this.txtsiteno);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txtbusno);
            this.Controls.Add(this.txtprice);
            this.Controls.Add(this.txtfrom);
            this.Controls.Add(this.txtto);
            this.Controls.Add(this.txtnumber);
            this.Controls.Add(this.txtPassname);
            this.Controls.Add(this.txtPassID);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel1);
            this.Name = "Passangers";
            this.Text = "Passangers";
            this.Load += new System.EventHandler(this.Passangers_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.passangerBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sahalTLDBDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label10;
        private Guna.UI2.WinForms.Guna2TextBox txtPassID;
        private Guna.UI2.WinForms.Guna2TextBox txtPassname;
        private Guna.UI2.WinForms.Guna2TextBox txtnumber;
        private Guna.UI2.WinForms.Guna2TextBox txtto;
        private Guna.UI2.WinForms.Guna2TextBox txtfrom;
        private Guna.UI2.WinForms.Guna2TextBox txtprice;
        private Guna.UI2.WinForms.Guna2TextBox txtbusno;
        private Guna.UI2.WinForms.Guna2TextBox txtsiteno;
        private System.Windows.Forms.Label label9;
        private Guna.UI2.WinForms.Guna2TextBox txttimeout;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private Guna.UI2.WinForms.Guna2Button guna2Button2;
        private Guna.UI2.WinForms.Guna2Button guna2Button3;
        private Guna.UI2.WinForms.Guna2Button guna2Button4;
        private Guna.UI2.WinForms.Guna2TextBox txtPsid;
        private System.Windows.Forms.Label label11;
        private Guna.UI2.WinForms.Guna2Button guna2Button5;
        private System.Windows.Forms.DataGridView dataGridView1;
        private SahalTLDBDataSet sahalTLDBDataSet;
        private System.Windows.Forms.BindingSource passangerBindingSource;
        private SahalTLDBDataSetTableAdapters.PassangerTableAdapter passangerTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn passIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn passNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn numberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gointoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn formtoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn priceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn busnoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sitenoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn timeoutDataGridViewTextBoxColumn;
        private Guna.UI2.WinForms.Guna2Button guna2Button6;
    }
}