﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SahlaTranportLogistics
{
    public partial class Cargo : Form
    {
        public Cargo()
        {
            InitializeComponent();
        }

        private void DisplayData()
        {
            SqlConnection con = new SqlConnection(@"Data Source=HP\ISMAIL;Initial Catalog=SahalTLDB;Integrated Security=True");
            SqlDataAdapter adapt;
            con.Open();
            DataTable dt = new DataTable();
            adapt = new SqlDataAdapter("select * from Passanger", con);
            adapt.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }

        private void Label4_Click(object sender, EventArgs e)
        {

        }

        private void Label9_Click(object sender, EventArgs e)
        {

        }

        private void Guna2Button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=HP\ISMAIL;Initial Catalog=SahalTLDB;Integrated Security=True");
            con.Open();
            try
            {
                string str = " INSERT INTO Cargo(Serialno,Sandername,sandernumber,Recievername,Recievernumber,GongTo,Formto,Quantity,Pirce) VALUES('" + txtSerialno.Text + "','" + txtsandername.Text + "' ,'" + txtsandernumber.Text + "' ,'" + txtRecievername.Text + "' ,'" + txtRecievernumber.Text + "','" + txtTO.Text + "','" + txtForm.Text + "','" + txtQuantity.Text + "','" + txtPrice.Text + "'); ";
                SqlCommand cmd = new SqlCommand(str, con);
                cmd.ExecuteNonQuery();
                string str1 = "select max(Serialno) from Cargo ;";
                SqlCommand cmd1 = new SqlCommand(str1, con);
                SqlDataReader dr = cmd1.ExecuteReader();
                if (dr.Read())
                {
                    MessageBox.Show("Successfully Saved. ");
                }
            }
            catch (SqlException excep)
            {
                MessageBox.Show(excep.Message);
            }
            con.Close();
           
        }

        private void Cargo_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'sahalTLDBDataSet1.Cargo' table. You can move, or remove it, as needed.
            this.cargoTableAdapter.Fill(this.sahalTLDBDataSet1.Cargo);

        }

        private void Guna2Button3_Click(object sender, EventArgs e)
        {
            MainPage mr  = new MainPage();
            mr.Show();
            this.Hide();
        }

        private void Guna2Button2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=HP\ISMAIL;Initial Catalog=SahalTLDB;Integrated Security=True");
            SqlCommand cmd;
            if (txtSerialno.Text != "" && txtsandername.Text != "" && txtsandernumber.Text != "" && txtRecievername.Text != "" && txtRecievernumber.Text != "" && txtTO.Text != "" && txtForm.Text != "" && txtQuantity.Text != "" && txtPrice.Text != "")
            {
                cmd = new SqlCommand("UPDATE Cargo set Serialno=@Serialno, Sandername=@Sandername,  sandernumber=@sandernumber, Recievername=@Recievername, Recievernumber=@Recievernumber, GongTo=@GongTo, Formto=@Formto,Quantity=@Quantity, Pirce=@Pirce  where Serialno=@Serialno", con);
                con.Open();

                cmd.Parameters.AddWithValue("@Serialno", txtSerialno.Text);
                cmd.Parameters.AddWithValue("@Sandername", txtsandername.Text);
                cmd.Parameters.AddWithValue("@sandernumber", txtsandernumber.Text);
                cmd.Parameters.AddWithValue("@Recievername", txtRecievername.Text);
                cmd.Parameters.AddWithValue("@Recievernumber", txtRecievernumber.Text);
                cmd.Parameters.AddWithValue("@GongTo", txtTO.Text);
                cmd.Parameters.AddWithValue("@Formto", txtForm.Text);
                cmd.Parameters.AddWithValue("@Quantity", txtQuantity.Text);
                cmd.Parameters.AddWithValue("@Pirce", txtPrice.Text);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Record Updated");
                con.Close();
            }
            else
            {
                MessageBox.Show("Please Select Record to Update");
            }
            DisplayData();
        }

        private void Guna2Button4_Click(object sender, EventArgs e)
        {

            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=HP\ISMAIL;Initial Catalog=SahalTLDB;Integrated Security=True");
                con.Open();

                string str = "DELETE FROM Cargo WHERE Serialno = '" + txtPsid.Text + "'";

                SqlCommand cmd = new SqlCommand(str, con);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Record Delete Successfully");

                using (SqlConnection newcon = new SqlConnection(@"Data Source=HP\ISMAIL;Initial Catalog=SahalTLDB;Integrated Security=True"))
                {
                    string str1 = @"SELECT * from Cargo";
                    SqlCommand cmd1 = new SqlCommand(str1, newcon);
                    SqlDataAdapter da = new SqlDataAdapter(cmd1);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dataGridView1.DataSource = new BindingSource(dt, null);

                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                MessageBox.Show("Please Enter Passanger Id");
            }
            DisplayData();


        }

        private void Guna2Button6_Click(object sender, EventArgs e)
        {
            txtSerialno.Text = "";
            txtsandername.Text = "";
            txtsandernumber.Text = "";
            txtRecievername.Text = "";
            txtRecievernumber.Text ="";
            txtTO.Text = "";
            txtForm.Text = "";
            txtQuantity.Text = "";
            txtPrice.Text = "";
        }

        private void Guna2Button5_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=HP\ISMAIL;Initial Catalog=SahalTLDB;Integrated Security=True");
                {
                    string str1 = @"SELECT * from Cargo where Serialno = '" + txtPsid.Text + "'";
                    SqlCommand cmd1 = new SqlCommand(str1, con);
                    SqlDataAdapter da = new SqlDataAdapter(cmd1);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dataGridView1.DataSource = new BindingSource(dt, null);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                MessageBox.Show("Please Enter Passanger ID");
            }
        }

        private void TxtSerialno_TextChanged(object sender, EventArgs e)
        {

        }

        private void Txtsandername_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
